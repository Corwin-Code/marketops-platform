from pathlib import Path
import argparse, datetime, hashlib, json, os, shutil, subprocess

p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
repo=Path('/Users/chzhengx/Code/personal/marketops-platform');frontend=repo/'frontend/marketops-console'
a.out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sources():
    paths=subprocess.check_output(['git','ls-files','-z','--','frontend/marketops-console','.github/workflows/frontend.yml','.node-version','.npmrc'],cwd=repo).decode().split('\0')
    return {p:sha(repo/p) for p in paths if p and (repo/p).is_file()}
before=sources();head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');status=git('status','--porcelain=v1')
(a.out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
(a.out/'source.diff').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','frontend/marketops-console'],cwd=repo))
env=os.environ.copy();env['PATH']='/Users/chzhengx/Library/Application Support/fnm/node-versions/v24.19.0/installation/bin:'+env.get('PATH','')
commands=[('node-version',['node','--version']),('npm-version',['npm','--version']),
          ('installed-dependencies',['npm','ls','--all']),('lint',['npm','run','lint']),
          ('format-check',['npm','run','format:check']),('typecheck',['npm','run','typecheck']),
          ('complete-unit-coverage',['npm','run','test:ci','--','--reporter=default','--reporter=json','--outputFile='+str(a.out/'vitest-results.json')]),
          ('build',['npm','run','build']),('bundle-isolation',['npm','run','verify:bundle']),('sbom',['npm','run','sbom'])]
records=[]
for name,argv in commands:
    started=utc();log=a.out/(name+'.log')
    with log.open('wb') as stream:r=subprocess.run(argv,cwd=frontend,env=env,stdout=stream,stderr=subprocess.STDOUT)
    records.append(dict(name=name,argv=argv,cwd=str(frontend),startedAtUTC=started,finishedAtUTC=utc(),exitCode=r.returncode,log=log.name,sha256=sha(log)))
    if r.returncode:break
after=sources();(a.out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
for src in [frontend/'coverage/coverage-final.json',frontend/'coverage/coverage-summary.json',repo/'build/supply-chain/frontend-sbom.json']:
    if src.is_file():shutil.copyfile(src,a.out/src.name)
summary=None
if (a.out/'vitest-results.json').is_file():
    j=json.loads((a.out/'vitest-results.json').read_text());summary={k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
receipt=dict(kind='EXACT_MEASURED_FRONTEND_COMPLETE_QUALITY_RUN',startedHead=head,startedTree=tree,initialGitStatus=status,
             commands=records,sourceManifestBeforeSha256=sha(a.out/'source-before.json'),sourceManifestAfterSha256=sha(a.out/'source-after.json'),
             sourceStable=before==after,headAfter=git('rev-parse','HEAD'),statusAfter=git('status','--porcelain=v1'),
             actualUnitSummary=summary,productionWriteEnabled=False,
             boundary='All configured frontend quality, actual coverage, build/bundle and SBOM validation on these exact source bytes. '
                      'Dirty candidate execution is bound to its source diff and fingerprint, not relabeled as a future commit. '
                      'Browser/HTTP, backend runtime and final remote CI require separate evidence.')
receipt['pass']=len(records)==len(commands) and all(r['exitCode']==0 for r in records) and before==after and receipt['headAfter']==head and bool(summary and summary['success'])
receipt['collectorSha256']=sha(Path(__file__));(a.out/Path(__file__).name).write_bytes(Path(__file__).read_bytes());(a.out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'out':str(a.out),'pass':receipt['pass'],'actualUnitSummary':summary,'completedCommands':len(records)}))
raise SystemExit(0 if receipt['pass'] else 1)

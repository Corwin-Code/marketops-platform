# W8 Governance and Infrastructure provenance

Actual completed Governance run 33967874687 / job 101311078382 and Infrastructure run 33967874661 / job 101311078585, both attempt 1, checked out merge 954ff3617402c3ff22fa8eb86d9aa8abaea76941. API parents are protected Base 08ad7da7d9e75b4ddd1c387a22ac0affba9e1430 and authored W8 9b6e6195f779bd80b1e8ed9c78d6ad9daa1a68af; merge/source tree is eb4bce1333c87e4de762f6f42bbd3bcd392fec38.

Governance validators and actual 410-test framework run passed. No per-method remote result artifact exists. Infrastructure records seven named Terraform mock-plan cases plus Python 9 + 13 = 22, combined 29; all passed. Artifact 9970007109 ZIP digest b2822859ce76dc0e5e092367e5e24d0afb9c16fc2afda21511e7d0f9e42e411c agrees with artifact API and same-job upload. Its 13 members, plan hashes and exact published-source lockfile hashes are verified.

The Infrastructure payload lacks embedded Head/run/job fields. Binding comes from actual checkout/API → same-job upload identity/digest → downloaded ZIP → printed summary/member hashes; do not invent an embedded stamp or expanded step-summary document.

One Infrastructure log download returned EOF. Original failure bytes are preserved privately; its stderr contains a transient signed redirect URL. Do not copy that raw stderr into a public archive. Use `failed-log-read-sanitized.txt` plus the original hash. Request attempt 2 read the same completed run attempt successfully.

Public tool/provider downloads and authorized GitHub network reads are real network activity. Terraform uses mock plans, readonly locks/backend=false and filtered environment; runtime tests use injected mocks. This proves no real account/apply or shared/production mutation within the inspected scope, not packet-level zero-network isolation. Remaining W8 CI/local full and all Controller conclusions are outside this two-context review.

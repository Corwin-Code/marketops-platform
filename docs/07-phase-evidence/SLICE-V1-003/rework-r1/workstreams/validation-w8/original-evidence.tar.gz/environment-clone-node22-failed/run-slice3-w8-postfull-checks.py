from pathlib import Path
import argparse, datetime, hashlib, json, subprocess

p=argparse.ArgumentParser()
p.add_argument('--kind',choices=['packaged-migration','environment-clone'],required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
repo=Path('/Users/chzhengx/Code/personal/marketops-platform')
full=Path('/tmp/slice3-r1-full-clean-w8-9b6e6195')
head='9b6e6195f779bd80b1e8ed9c78d6ad9daa1a68af'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt=json.loads((full/'run-receipt.json').read_text())
assert receipt.get('completePass') is True, 'Completed exact full run required'
assert git('rev-parse','HEAD')==head==receipt['head'], 'Exact W8 source required'
assert not git('status','--porcelain=v1'), 'Clean source required'
jar=repo/'backend/marketops-server/target/marketops-server-0.1.0-SNAPSHOT.jar'
verified=full/'artifacts/jars/marketops-server-0.1.0-SNAPSHOT.jar'
assert sha(jar)==sha(verified), 'Only full-verified JAR allowed'
a.out.mkdir(exist_ok=False)
commands=([('packaged-migration',['python3','scripts/verify_migration_artifact.py','--output',str(a.out/'artifacts')])]
          if a.kind=='packaged-migration' else
          [('doctor',['make','doctor']),('fresh-clone-offline',['bash','scripts/fresh_clone_check.sh','--offline'])])
records=[]
for name,argv in commands:
    start=utc()
    log=a.out/(name+'.log')
    with log.open('wb') as output:
        result=subprocess.run(argv,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
    records.append(dict(name=name,command=argv,workingDirectory=str(repo),startedAtUTC=start,
                        finishedAtUTC=utc(),exitCode=result.returncode,log=log.name,sha256=sha(log)))
    if result.returncode: break
result=dict(kind='ACTUAL_W8_POST_FULL_'+a.kind.upper().replace('-','_'),head=head,tree=receipt['tree'],
            fullRunReceiptSha256=sha(full/'run-receipt.json'),fullVerifiedJarSha256=sha(verified),
            commands=records,headAfter=git('rev-parse','HEAD'),statusAfter=git('status','--porcelain=v1'),
            verifiedJarStillEqual=sha(jar)==sha(verified),productionWriteEnabled=False,
            scope=('Exact full-verified JAR resolver and minimal synthetic local container build; no DB connection, '
                   'Provider call, application run, shared port/environment or production deployment.' if a.kind=='packaged-migration' else
                   'Doctor dependency/port inspection and independent Git-object fresh clone in offline mode. '
                   'Existing user containers, busy5432 and ignored configuration untouched; no database connection '
                   'or real Provider/shared/production access. This is not full-mode fresh-clone runtime evidence.'))
result['pass']=(len(records)==len(commands) and all(r['exitCode']==0 for r in records)
                and result['headAfter']==head and not result['statusAfter'] and result['verifiedJarStillEqual'])
result['collectorSha256']=sha(Path(__file__))
(a.out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
(a.out/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
print(json.dumps({'out':str(a.out),'pass':result['pass']}))
raise SystemExit(0 if result['pass'] else 1)

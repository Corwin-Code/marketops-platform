from pathlib import Path
import subprocess,json,datetime,hashlib,concurrent.futures
r=Path('/tmp/slice3-w8-frontend-ci')
def fetch(pair):
 name,url=pair
 for attempt in [1,2]:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(['gh','api',url],capture_output=True);finish=datetime.datetime.now(datetime.timezone.utc).isoformat()
  (r/(name+f'.attempt-{attempt}.stderr.txt')).write_bytes(p.stderr)
  record={'endpoint':url,'startedAtUTC':start,'completedAtUTC':finish,'attempt':attempt,'exitCode':p.returncode,'responseSha256':hashlib.sha256(p.stdout).hexdigest(),'bytes':len(p.stdout)}
  (r/(name+f'.attempt-{attempt}.request.json')).write_text(json.dumps(record,indent=2)+'\n')
  if p.returncode==0:(r/name).write_bytes(p.stdout);return name,len(p.stdout)
  (r/(name+f'.attempt-{attempt}.failed-response')).write_bytes(p.stdout)
 raise RuntimeError('read-only download failed: '+name)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 print(list(pool.map(fetch,[('run-final.json','repos/Corwin-Code/marketops-platform/actions/runs/33967874665'),('jobs-latest.json','repos/Corwin-Code/marketops-platform/actions/runs/33967874665/attempts/1/jobs?per_page=100'),('artifacts.json','repos/Corwin-Code/marketops-platform/actions/runs/33967874665/artifacts?per_page=100'),('logs.zip','repos/Corwin-Code/marketops-platform/actions/runs/33967874665/attempts/1/logs'),('tested-merge-commit.json','repos/Corwin-Code/marketops-platform/git/commits/954ff3617402c3ff22fa8eb86d9aa8abaea76941')])) )
arts=json.loads((r/'artifacts.json').read_text())['artifacts']
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 print(list(pool.map(fetch,[(f'artifact-{a["id"]}.zip',f'repos/Corwin-Code/marketops-platform/actions/artifacts/{a["id"]}/zip') for a in arts])))

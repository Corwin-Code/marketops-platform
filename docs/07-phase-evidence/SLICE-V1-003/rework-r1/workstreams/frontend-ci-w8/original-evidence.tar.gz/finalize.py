from pathlib import Path
import ast,re,zipfile,json,hashlib,datetime
r=Path('/tmp/slice3-w8-frontend-ci');repo=Path('/Users/chzhengx/Code/personal/marketops-platform')
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):return {'path':str(p),'sha256':sha(Path(p).read_bytes())}
asts=ast.parse((repo/'scripts/validate_governance.py').read_text());assignment=next(a for a in asts.body if isinstance(a,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SECRET_PATTERNS' for t in a.targets));patterns=[re.compile(ast.literal_eval(n.args[0])) for n in assignment.value.elts]+[re.compile(r'\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b'),re.compile(r'(?i)\bBearer\s+[A-Za-z0-9_.-]{20,}')]
arts=json.loads((r/'artifacts.json').read_text())['artifacts'];a=next(a for a in arts if a['name']=='advertising-browser-screenshots');pngs=[]
with zipfile.ZipFile(r/f'artifact-{a["id"]}.zip') as z:
 for n in z.namelist():
  if n.endswith('.png'):
   b=z.read(n);assert b[:8]==b'\x89PNG\r\n\x1a\n';pngs.append({'member':n,'sha256':sha(b),'bytes':len(b),'width':int.from_bytes(b[16:20],'big'),'height':int.from_bytes(b[20:24],'big')})
review={'kind':'ACTUAL_W8_CI_SCREENSHOT_INVENTORY_AND_BOUNDED_VISUAL_REVIEW','recordedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runId':33967874665,'jobId':101311078665,'artifact':ref(r/f'artifact-{a["id"]}.zip'),'originalPngCount':len(pngs),'originals':pngs,'detailedVisualInspections':[{'file':'inspected-screenshots/maker-minimum-disclosure.png','observed':'Maker identity/native bid and affected membership remain visible; financial measures and factors are MASKED. This particular API graph explicitly names a fictional protocol fixture; its synthetic VERIFIED label is not real marketplace authority.'},{'file':'inspected-screenshots/keyboard-page-two-six-visible-cases.png','observed':'Page 2 has six visible synthetic WATCH rows, explicit MASKED financial fields, Russian text, and unresolved/no-critical-observation SLO state; no false healthy badge.'}],'overviewVisualInspections':[{'file':'inspected-screenshots/WILDBERRIES-owner-manual-issued.png','observed':'Long exact-packet page, distinct placement/minor-unit native profile and Manual-issued section visible; overview only because the tool resized the tall original. Exact value/UNVERIFIED assertions are proved by the named actual browser test, not claimed as all-text visual inspection.'},{'file':'inspected-screenshots/HISTORY_REGRESSION-actual-http-history.png','observed':'Ordered multi-stage Outcome history and appended fourth regression restatement are visible, with synthetic read-oracle labels; overview only, not canonical calculation evidence.'}],'boundary':'All 26 unmodified original PNG byte identities are catalogued; two detailed and two overview visual inspections, not a claim that every screenshot or every small line was visually read. Actual keyboard behavior comes from the named test assertions.'}
(r/'visual-review.json').write_text(json.dumps(review,indent=2)+'\n')
d=json.loads((r/'receipt.json').read_text());d['visualReview']=ref(r/'visual-review.json');d['runApi']=ref(r/'run-final.json');d['jobsApi']=ref(r/'jobs-latest.json');d['artifactsApi']=ref(r/'artifacts.json');d['testedMergeApi']=ref(r/'tested-merge-commit.json');d['downloadAttemptRecords']=[ref(p) for p in sorted(r.glob('*.attempt-*.request.json'))];(r/'receipt.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
checked=[];matches=[];total=0
for p in sorted(r.iterdir()):
 if not p.is_file() or p.suffix=='.py' or p.name in ['publication-scan.json','summary.json']:continue
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:entries=[(str(p.name)+'!'+n,z.read(n)) for n in z.namelist() if not n.endswith('/')]
 else:entries=[(p.name,p.read_bytes())]
 for name,b in entries:
  try:t=b.decode('utf-8-sig')
  except UnicodeDecodeError:continue
  checked.append({'path':name,'sha256':sha(b),'bytes':len(b)});total+=len(b)
  for i,pattern in enumerate(patterns):
   found=list(pattern.finditer(t))
   if found:matches.append({'path':name,'patternIndex':i,'count':len(found)})
scan={'kind':'BOUNDED_RAW_CI_EVIDENCE_PUBLICATION_PATTERN_SCAN','createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'policySource':ref(repo/'scripts/validate_governance.py'),'patternCount':len(patterns),'textFilesAndMembers':len(checked),'textBytes':total,'matchesWithoutValues':matches,'matchCount':sum(m['count'] for m in matches),'scannedFiles':checked,'limit':'Repository seven secret patterns plus JWT/Bearer shapes; no matched values printed. Binary PNG/ZIP container bytes and collector Python source excluded; text members within every downloaded ZIP are included. This is an evidence-file scan, not a new CI security verdict.'};(r/'publication-scan.json').write_text(json.dumps(scan,indent=2)+'\n')
summary={'receipt':ref(r/'receipt.json'),'namedBrowser':ref(r/'named-browser-results.json'),'runtimeProvenance':ref(r/'backend-runtime-provenance.json'),'visualReview':ref(r/'visual-review.json'),'publicationScan':ref(r/'publication-scan.json'),'counts':{'frontendUnit':308,'legacyBrowser':25,'advertisingBrowser':12,'originalPng':26},'scanMatches':scan['matchCount'],'runId':33967874665,'attempt':1,'testedPrHead':d['testedPrHead'],'testedMerge':d['testedCheckoutMergeSha'],'tree':d['testedCheckoutTree'],'result':'ACTUAL_FRONTEND_CI_PASS; COMPLETE_BACKEND_AND_OTHER_GATES_SEPARATE'};(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));assert not matches,matches

from pathlib import Path
import datetime,hashlib,json,re,subprocess,zipfile
r=Path('/tmp/slice3-w8-frontend-ci');repo=Path('/Users/chzhengx/Code/personal/marketops-platform');head='9b6e6195f779bd80b1e8ed9c78d6ad9daa1a68af';tree='eb4bce1333c87e4de762f6f42bbd3bcd392fec38';run=json.loads((r/'run-final.json').read_text());jobs=json.loads((r/'jobs-latest.json').read_text())['jobs'];arts=json.loads((r/'artifacts.json').read_text())['artifacts']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'sha256':sha(p)}
assert run['head_sha']==head and run['conclusion']=='success'
assert all(j['conclusion']=='success' for j in jobs)
ansi=re.compile(r'\x1b\[[0-9;]*m');alltests=[];members=[]
with zipfile.ZipFile(r/'logs.zip') as z:
 checkout=z.read('frontend-test/2_Checkout repository.txt').decode('utf-8-sig');lines=checkout.splitlines();merge=None
 for i,l in enumerate(lines):
  if '[command]/usr/bin/git log -1 --format=%H' in l:
   m=re.search(r'\b([a-f0-9]{40})\b',lines[i+1]);assert m;merge=m.group(1)
 assert merge
 for step,count,layer in [(11,25,'LEGACY_BROWSER'),(13,12,'ADVERTISING_BROWSER')]:
  name=next(n for n in z.namelist() if n.startswith('frontend-test/'+str(step)+'_'));raw=z.read(name);text=ansi.sub('',raw.decode('utf-8-sig'));matches=[]
  for i,line in enumerate(text.splitlines(),1):
   m=re.search(r'^(\S+)\s+✓\s+(\d+)\s+(tests/[^:]+):(\d+):(\d+)\s+›\s+(.+)\s+\(([^()]*)\)\s*$',line)
   if m:
    chain=m.group(6).split(' › ');source='frontend/marketops-console/'+m.group(3);content=(repo/source).read_bytes();git=subprocess.check_output(['git','show',head+':'+source],cwd=repo);assert content==git
    matches.append({'layer':layer,'title':chain[-1],'suiteTitles':chain[:-1],'fullDisplayTitle':m.group(6),'sourcePath':source,'sourceSha256':hashlib.sha256(content).hexdigest(),'sourceLine':int(m.group(4)),'sourceColumn':int(m.group(5)),'ordinal':int(m.group(2)),'observedCompletionTimeUTC':m.group(1),'durationDisplay':m.group(7),'status':'passed','testedPrHead':head,'testedCheckoutMergeSha':merge,'logArchive':ref(r/'logs.zip'),'logMember':name,'logMemberSha256':hashlib.sha256(raw).hexdigest(),'logLine':i,'jobId':101311078665,'step':step})
  assert len(matches)==count,(name,len(matches));assert f'{count} passed' in text;alltests+=matches;members.append({'step':step,'archiveMember':name,'memberSha256':hashlib.sha256(raw).hexdigest(),'matchedNamedTests':len(matches)})
 unitname=next(n for n in z.namelist() if n.startswith('frontend-test/6_'));raw=z.read(unitname);unit=ansi.sub('',raw.decode('utf-8-sig'));assert '308 passed' in unit and '22 passed' in unit
 unitproof={'layer':'FRONTEND_UNIT_AGGREGATE_ONLY','testsPassed':308,'filesPassed':22,'logArchive':ref(r/'logs.zip'),'logMember':unitname,'logMemberSha256':hashlib.sha256(raw).hexdigest(),'limit':'Normal Vitest reporter records file-level and aggregate counts here. Individual test titles are bound to W6 local JSON separately, never represented as W8 per-title JSON.'}
 sbname=next(n for n in z.namelist() if n.startswith('frontend-build/7_'));sb=z.read(sbname).decode('utf-8-sig');assert 'skipped validating BOM' not in sb
 sbproof={'command':'npm run sbom; npm ls --all --json','status':'SUCCESS_WITHOUT_VALIDATOR_SKIP','archiveMember':sbname,'memberSha256':hashlib.sha256(z.read(sbname)).hexdigest()}
mergejson=json.loads((r/'tested-merge-commit.json').read_text());assert mergejson['sha']==merge
artifactproof=[]
for a in arts:
 p=r/('artifact-'+str(a['id'])+'.zip');assert a['digest']=='sha256:'+sha(p)
 with zipfile.ZipFile(p) as z:
  artifactproof.append({'artifactId':a['id'],'name':a['name'],'download':ref(p),'serverDigest':a['digest'],'members':[{'path':n,'sha256':hashlib.sha256(z.read(n)).hexdigest(),'bytes':len(z.read(n))} for n in z.namelist() if not n.endswith('/')]})
assert sum(1 for a in artifactproof if a['name']=='advertising-browser-screenshots' for m in a['members'] if m['path'].endswith('.png'))==26
(r/'named-browser-results.json').write_text(json.dumps({'testedPrHead':head,'testedCheckoutMergeSha':merge,'testedCheckoutTree':mergejson['tree']['sha'],'runId':33967874665,'jobId':101311078665,'tests':alltests,'limit':'Parsed actual successful Playwright lines from unmodified GitHub job logs. No local result substitution. No raw trace/headers copied.'},ensure_ascii=False,indent=2)+'\n')
proof={'recordedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runId':33967874665,'runAttempt':1,'url':run['html_url'],'runConclusion':run['conclusion'],'testedPrHead':head,'reportedPrTree':tree,'testedCheckoutMergeSha':merge,'testedCheckoutTree':mergejson['tree']['sha'],'mergeParents':[p['sha'] for p in mergejson['parents']],'mergeTreeEqualsPrHeadTree':mergejson['tree']['sha']==tree,'jobs':[{'id':j['id'],'name':j['name'],'startedAt':j['started_at'],'completedAt':j['completed_at'],'conclusion':j['conclusion']} for j in jobs],'rawLogs':ref(r/'logs.zip'),'namedBrowserResults':ref(r/'named-browser-results.json'),'legacyBrowserNamedPassed':25,'advertisingBrowserNamedPassed':12,'originalRemoteScreenshotCount':26,'unitResult':unitproof,'sbomResult':sbproof,'artifacts':artifactproof,'downloadLimit':'Every read-only download completed on its first attempt; every ZIP SHA matches its GitHub artifact digest. No signed download URL is persisted in this receipt.','localW6Evidence':ref(Path('/tmp/slice3-w6-browser-evidence/verification-summary.json')),'w7ToW8Boundary':{'frontendSource':'Unchanged exact source bytes; actual W8 CI executions are recorded here instead of inheriting W7 results.','backendSource':'Changed W8 runtime; actual same-job checkout, Maven source compilation and both fixture starts are bound separately in backend-runtime-provenance.json.'},'boundary':'This is exact Frontend workflow evidence only. Root complete backend, remaining required contexts, security result and engineering/Controller judgment remain separate.'}
(r/'receipt.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'receipt':ref(r/'receipt.json'),'merge':merge,'mergeTree':mergejson['tree']['sha'],'counts':[25,12,308],'screenshots':26,'named':ref(r/'named-browser-results.json')},indent=2))

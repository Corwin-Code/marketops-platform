#!/usr/bin/env python3
"""Offline, read-only provenance audit of a completed collect-slice3-pr-ci snapshot.

Reads frozen GitHub API/log/artifact files and exact Git objects. Never fetches,
checks out, writes the repository, invokes tests, contacts Docker, or changes CI.
Exit 0 means the specified provenance predicates passed; never finding/AC closure.
Exit 2 means missing, ambiguous, unsuccessful or mismatched evidence (fail closed).
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import zipfile

BACKEND = 'backend/marketops-server'
BASE = '08ad7da7d9e75b4ddd1c387a22ac0affba9e1430'
JOBS = {'backend-build': 'backend-test-reports',
        'backend-integration': 'backend-integration-reports'}
SHA40 = re.compile(r'^[0-9a-f]{40}$')
SHA256 = re.compile(r'^[0-9a-f]{64}$')
TIMESTAMP = re.compile(r'^\d{4}-\d\d-\d\dT\S+\s')


class Refused(Exception):
    pass


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc(value):
    if not isinstance(value, str):
        raise Refused('Missing/non-string timestamp')
    try:
        result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError as exc:
        raise Refused('Invalid timestamp') from exc
    if result.tzinfo is None:
        raise Refused('Timestamp has no offset')
    return result


def within(path, parent):
    return path == parent or parent in path.parents


class Audit:
    def __init__(self, args):
        self.args = args
        self.snapshot = args.snapshot.resolve()
        self.repo = args.repo.resolve()
        self.out = args.out.resolve()
        if within(self.out, self.snapshot) or within(self.out, self.repo):
            raise Refused('Output must be outside snapshot and repository')
        if self.out.exists():
            raise Refused('Output must be a new directory; never overwrite evidence')
        self.checks = []
        self.inputs = {}
        self.results = []
        self.git_cache = None
        self.report = {
            'schemaVersion': '1.0', 'kind': 'BACKEND_CI_ARTIFACT_PROVENANCE_ONLY',
            'observedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'expectedSourceHead': args.head, 'expectedProtectedBase': args.base,
            'snapshot': str(self.snapshot), 'gitObjectRepository': str(self.repo),
            'tool': {'path': str(Path(__file__).resolve()), 'sha256': sha(Path(__file__).read_bytes())},
            'readOnlyBoundary': 'Offline archived inputs and read-only Git object commands only; no tests, network, checkout, Docker or repository writes.',
            'decisionBoundary': 'No automatic assessment of 22 findings, 200 criteria, performance semantics, production permission or Controller approval.',
            'latestScope': 'Latest captured API attempt/check in this frozen snapshot, not a claim about future remote state.',
        }

    def check(self, condition, rule, actual=None, expected=None, fatal=False):
        row = {'rule': rule, 'status': 'PASS' if condition else 'FAIL'}
        if actual is not None:
            row['actual'] = actual
        if expected is not None:
            row['expected'] = expected
        self.checks.append(row)
        if not condition and fatal:
            raise Refused(rule)
        return condition

    def equal(self, actual, expected, rule, fatal=False):
        return self.check(actual == expected, rule, actual, expected, fatal)

    def read(self, relative):
        path = (self.snapshot / relative).resolve()
        if not within(path, self.snapshot) or not path.is_file():
            raise Refused('Missing or escaped snapshot file: ' + str(relative))
        raw = path.read_bytes()
        rel = str(path.relative_to(self.snapshot))
        old = self.inputs.get(rel)
        item = {'path': rel, 'bytes': len(raw), 'sha256': sha(raw)}
        if old and old != item:
            raise Refused('Snapshot changed while reading: ' + rel)
        self.inputs[rel] = item
        return raw

    def data(self, relative):
        try:
            return json.loads(self.read(relative))
        except (ValueError, UnicodeDecodeError) as exc:
            raise Refused('Invalid JSON: ' + str(relative)) from exc

    def git(self, *args):
        env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1', GIT_NO_LAZY_FETCH='1')
        result = subprocess.run(['git', '-c', 'protocol.allow=never', '-C', str(self.repo), *args], stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, env=env, check=False)
        if result.returncode:
            raise Refused('Read-only Git command failed: ' + ' '.join(args[:2]))
        return result.stdout

    def one(self, items, rule):
        self.equal(len(items), 1, rule + '.unique', fatal=True)
        return items[0]

    def archive(self, relative):
        # Keep the checksum of the original ZIP; all reads below are in memory.
        import io
        raw = self.read(relative)
        try:
            archive = zipfile.ZipFile(io.BytesIO(raw))
            names = archive.namelist()
            self.equal(len(names), len(set(names)), str(relative) + '.no_duplicate_members', fatal=True)
            for name in names:
                p = PurePosixPath(name)
                self.check(not p.is_absolute() and '..' not in p.parts and '\\' not in name,
                           str(relative) + '.safe_member_name', fatal=True)
                mode = archive.getinfo(name).external_attr >> 16
                self.check((mode & 0o170000) != 0o120000,
                           str(relative) + '.no_symlink_member', fatal=True)
            return archive, raw
        except zipfile.BadZipFile as exc:
            raise Refused('Invalid ZIP: ' + str(relative)) from exc

    def member(self, archive, accepted, label):
        name = self.one([n for n in archive.namelist() if n in accepted], label)
        info = archive.getinfo(name)
        self.check(info.file_size <= 128 * 1024 * 1024, label + '.bounded_size', fatal=True)
        raw = archive.read(name)
        return raw, {'member': name, 'bytes': len(raw), 'sha256': sha(raw)}

    def backend_member(self, archive, filename, label):
        return self.member(archive, [BACKEND + '/target/' + filename, 'target/' + filename, filename], label)

    def job_log(self, archive, job_name, step_name):
        pattern = re.compile(r'^' + re.escape(job_name) + r'/\d+_' + re.escape(step_name) + r'\.txt$')
        name = self.one([n for n in archive.namelist() if pattern.fullmatch(n)], job_name + '.' + step_name)
        raw = archive.read(name)
        return [TIMESTAMP.sub('', line) for line in raw.decode('utf-8-sig').splitlines()], {
            'member': name, 'bytes': len(raw), 'sha256': sha(raw)}

    def source_git_bytes(self):
        if self.git_cache is not None:
            return self.git_cache
        raw = self.git('ls-tree', '-rz', self.args.head, '--',
                       BACKEND + '/src/main', BACKEND + '/src/test', BACKEND + '/pom.xml')
        entries = []
        for entry in raw.split(b'\0'):
            if not entry:
                continue
            meta, name = entry.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            path = name.decode('utf-8')
            self.check(kind == 'blob' and mode in ('100644', '100755'),
                       'source_git.regular_tracked_input', path, fatal=True)
            self.check(path.startswith(BACKEND + '/'), 'source_git.backend_prefix', fatal=True)
            entries.append((path[len(BACKEND) + 1:], oid))
        self.check(bool(entries), 'source_git.nonempty', fatal=True)
        env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1', GIT_NO_LAZY_FETCH='1')
        process = subprocess.Popen(['git', '-c', 'protocol.allow=never', '-C', str(self.repo), 'cat-file', '--batch'],
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        result = {}
        try:
            for path, oid in entries:
                process.stdin.write((oid + '\n').encode()); process.stdin.flush()
                header = process.stdout.readline().decode().strip().split()
                if len(header) != 3 or header[0] != oid or header[1] != 'blob':
                    raise Refused('git cat-file returned an unexpected object header')
                size = int(header[2]); remaining = size; digest = hashlib.sha256()
                while remaining:
                    chunk = process.stdout.read(min(remaining, 1024 * 1024))
                    if not chunk:
                        raise Refused('Truncated Git blob stream')
                    digest.update(chunk); remaining -= len(chunk)
                if process.stdout.read(1) != b'\n':
                    raise Refused('Git blob stream delimiter missing')
                result[path] = {'gitBlob': oid, 'bytes': size, 'sha256': digest.hexdigest()}
            process.stdin.close()
            self.equal(process.wait(timeout=30), 0, 'source_git.batch_exit', fatal=True)
        finally:
            if process.poll() is None:
                process.kill(); process.wait()
        self.git_cache = result
        return result

    def common(self):
        receipt = self.data('receipt.json')
        self.equal(receipt.get('sourceHead'), self.args.head, 'snapshot.source_head', fatal=True)
        self.check(receipt.get('headAndDraftStable') is True, 'snapshot.pr_stable', fatal=True)
        self.equal(receipt.get('repository'), self.args.repository, 'snapshot.repository', fatal=True)
        self.check(receipt.get('downloadRequested') is True, 'snapshot.download_requested', fatal=True)
        pr = self.data('pr.json'); final_pr = self.data('pr-final-readback.json')
        self.pr_number = receipt.get('pr')
        self.check(isinstance(self.pr_number, int), 'snapshot.pr_number', fatal=True)
        for label, item in [('first', pr), ('final', final_pr)]:
            self.equal(item.get('number'), self.pr_number, 'pr.' + label + '.number', fatal=True)
            self.equal(item.get('head', {}).get('sha'), self.args.head, 'pr.' + label + '.head', fatal=True)
            self.equal(item.get('base', {}).get('sha'), self.args.base, 'pr.' + label + '.base', fatal=True)
            self.equal(item.get('head', {}).get('repo', {}).get('full_name'), self.args.repository,
                       'pr.' + label + '.repository', fatal=True)
            self.check(item.get('draft') is True and item.get('state') == 'open' and
                       item.get('merged') is False and item.get('auto_merge') is None,
                       'pr.' + label + '.authorized_draft_boundary', fatal=True)
        merge = self.data('pr-tested-merge-current.json')
        self.merge = merge.get('sha'); self.tree = merge.get('tree')
        self.check(bool(SHA40.fullmatch(self.merge or '')) and bool(SHA40.fullmatch(self.tree or '')),
                   'merge.valid_identity', fatal=True)
        if self.args.tested_merge:
            self.equal(self.merge, self.args.tested_merge, 'merge.explicit_expected', fatal=True)
        self.equal(merge.get('parents'), [self.args.base, self.args.head], 'merge.exact_parent_order', fatal=True)
        self.equal(receipt.get('currentPrMerge'), merge, 'merge.collector_receipt_matches', fatal=True)
        self.equal(pr.get('merge_commit_sha'), self.merge, 'merge.first_pr_matches', fatal=True)
        self.equal(final_pr.get('merge_commit_sha'), self.merge, 'merge.final_pr_matches', fatal=True)
        published = self.git('rev-parse', self.args.head + '^{commit}').decode().strip()
        tree = self.git('rev-parse', self.args.head + '^{tree}').decode().strip()
        self.equal(published, self.args.head, 'git.exact_published_head', fatal=True)
        # This R1 transport requires the tested merge tree to preserve the published tree.
        self.equal(tree, self.tree, 'merge.tree_equals_exact_published_tree', fatal=True)
        self.report['testedMerge'] = merge
        self.report['publishedGitTree'] = tree
        control_sources = []
        for path in ['.github/workflows/backend.yml',
                     'scripts/validation/collect_slice3_runtime_resources.py',
                     BACKEND + '/src/test/java/com/mimococo/marketops/advertisingefficiency/internal/application/AdvertisingCapacityEvidence.java',
                     BACKEND + '/src/test/java/com/mimococo/marketops/advertisingefficiency/internal/application/AdvertisingOrchestrationCapacityIT.java']:
            raw = self.git('cat-file', 'blob', self.args.head + ':' + path)
            oid = self.git('rev-parse', self.args.head + ':' + path).decode().strip()
            control_sources.append({'path': path, 'gitBlob': oid, 'bytes': len(raw), 'sha256': sha(raw)})
        self.report['exactPublishedProvenanceControlSources'] = control_sources
        self.checks_api = self.data('check-runs.json')
        self.index = self.data('run-job-artifact-index.json')
        self.workflow_runs = self.data('workflow-runs.json')

    def verify_job(self, job_name, artifact_name):
        label = job_name
        result = {'job': job_name, 'artifactName': artifact_name}
        self.results.append(result)
        candidates = [c for c in self.checks_api if c.get('name') == job_name and c.get('app', {}).get('id') == 15368]
        self.check(bool(candidates), label + '.check_present', fatal=True)
        check = max(candidates, key=lambda c: c['id'])
        self.equal(check.get('head_sha'), self.args.head, label + '.latest_check_head', fatal=True)
        self.check(check.get('status') == 'completed' and check.get('conclusion') == 'success',
                   label + '.latest_check_success', fatal=True)
        match = re.fullmatch(r'https://github\.com/' + re.escape(self.args.repository) + r'/actions/runs/(\d+)/job/(\d+)',
                             check.get('details_url', ''))
        self.check(match is not None, label + '.check_exact_run_job_url', fatal=True)
        run_id, job_id = map(int, match.groups())
        index = self.one([r for r in self.index if r.get('runId') == run_id], label + '.index_run')
        attempt = index.get('attempt')
        self.check(isinstance(attempt, int) and attempt > 0, label + '.attempt_present', fatal=True)
        prefix = 'runs/{}-attempt-{}/'.format(run_id, attempt)
        run = self.data(prefix + 'run.json'); jobs = self.data(prefix + 'jobs.json')
        artifacts = self.data(prefix + 'artifacts.json')
        self.equal(run.get('id'), run_id, label + '.run_id', fatal=True)
        for key, raw_key in [('headSha', 'head_sha'), ('status', 'status'), ('conclusion', 'conclusion')]:
            self.equal(index.get(key), run.get(raw_key), label + '.index_run_' + key, fatal=True)
        self.equal(run.get('run_attempt'), attempt, label + '.latest_run_attempt', fatal=True)
        self.equal(run.get('head_sha'), self.args.head, label + '.run_head', fatal=True)
        self.equal(run.get('event'), 'pull_request', label + '.run_event', fatal=True)
        self.equal(run.get('repository', {}).get('full_name'), self.args.repository, label + '.run_repository', fatal=True)
        self.equal(run.get('path'), '.github/workflows/backend.yml', label + '.workflow_path', fatal=True)
        self.equal(check.get('check_suite', {}).get('id'), run.get('check_suite_id'), label + '.check_suite_id', fatal=True)
        self.check(run.get('status') == 'completed' and run.get('conclusion') == 'success',
                   label + '.latest_run_success', fatal=True)
        matching_runs = [r for r in self.workflow_runs if r.get('id') == run_id]
        wr = self.one(matching_runs, label + '.workflow_listing_run')
        self.equal(wr.get('run_attempt'), attempt, label + '.workflow_listing_attempt', fatal=True)
        self.equal(wr.get('head_sha'), self.args.head, label + '.workflow_listing_head', fatal=True)
        associated_pr = self.one([p for p in run.get('pull_requests', []) if p.get('number') == self.pr_number], label + '.run_pr')
        self.equal(associated_pr.get('head', {}).get('sha'), self.args.head, label + '.run_pr_head', fatal=True)
        self.equal(associated_pr.get('base', {}).get('sha'), self.args.base, label + '.run_pr_base', fatal=True)
        job = self.one([j for j in jobs if j.get('name') == job_name], label + '.job')
        for key, value in [('id', job_id), ('run_id', run_id), ('run_attempt', attempt), ('head_sha', self.args.head)]:
            self.equal(job.get(key), value, label + '.job_' + key, fatal=True)
        indexed_job = self.one([j for j in index.get('jobs', []) if j.get('name') == job_name], label + '.indexed_job')
        for key, raw_key in [('id', 'id'), ('headSha', 'head_sha'), ('status', 'status'), ('conclusion', 'conclusion')]:
            self.equal(indexed_job.get(key), job.get(raw_key), label + '.index_job_' + key, fatal=True)
        self.equal(check['id'], job_id, label + '.check_job_identity', fatal=True)
        self.check(job.get('status') == 'completed' and job.get('conclusion') == 'success', label + '.job_success', fatal=True)
        self.equal(job.get('check_run_url', '').rsplit('/', 1)[-1], str(check['id']), label + '.job_check_url', fatal=True)
        started, completed = utc(job.get('started_at')), utc(job.get('completed_at'))
        self.check(started <= completed, label + '.job_time_order', fatal=True)
        logs, raw_logs = self.archive(prefix + 'logs.zip')
        self.equal(index.get('logArchive', {}).get('sha256'), sha(raw_logs), label + '.log_download_checksum', fatal=True)
        checkout_lines, checkout_ref = self.job_log(logs, job_name, 'Checkout repository')
        observed = []
        for n, line in enumerate(checkout_lines):
            if re.search(r'\[command\].*\bgit log -1 --format=%H\s*$', line):
                following = next((v.strip() for v in checkout_lines[n + 1:] if v.strip()), '')
                if SHA40.fullmatch(following):
                    observed.append(following)
        self.equal(observed, [self.merge], label + '.actual_checkout_git_log', fatal=True)
        checkout_text = '\n'.join(checkout_lines)
        self.check(('+' + self.merge + ':refs/remotes/pull/' + str(self.pr_number) + '/merge') in checkout_text,
                   label + '.exact_merge_fetch_ref', fatal=True)
        result.update({'runId': run_id, 'attempt': attempt, 'jobId': job_id, 'checkId': check['id'],
                       'startedAt': job['started_at'], 'completedAt': job['completed_at'], 'checkoutLog': checkout_ref})
        artifact = self.one([a for a in artifacts if a.get('name') == artifact_name], label + '.artifact_api')
        artifact_id = artifact.get('id')
        self.check(isinstance(artifact_id, int) and artifact.get('expired') is False, label + '.artifact_available', fatal=True)
        self.equal(artifact.get('workflow_run', {}).get('id'), run_id, label + '.artifact_api_run', fatal=True)
        self.equal(artifact.get('workflow_run', {}).get('head_sha'), self.args.head, label + '.artifact_api_head', fatal=True)
        upload_step = 'Publish the test reports' if job_name == 'backend-build' else 'Publish the integration test reports'
        step = self.one([s for s in job.get('steps', []) if s.get('name') == upload_step], label + '.upload_step')
        self.check(step.get('status') == 'completed' and step.get('conclusion') == 'success', label + '.upload_success', fatal=True)
        upload_lines, upload_ref = self.job_log(logs, job_name, upload_step)
        upload_text = '\n'.join(upload_lines)
        finalized_ids = re.findall(r'^Artifact ' + re.escape(artifact_name) + r' successfully finalized\. Artifact ID (\d+)$', upload_text, re.M)
        uploaded_ids = re.findall(r'^Artifact ' + re.escape(artifact_name) + r' has been successfully uploaded! Final size is \d+ bytes\. Artifact ID is (\d+)$', upload_text, re.M)
        uploaded_digests = re.findall(r'^SHA256 digest of uploaded artifact is ([0-9a-f]{64})$', upload_text, re.M)
        self.equal(finalized_ids, [str(artifact_id)], label + '.finalized_exact_artifact_id', fatal=True)
        self.equal(uploaded_ids, [str(artifact_id)], label + '.upload_exact_artifact_id', fatal=True)
        self.check(re.search(r'\bname:\s*' + re.escape(artifact_name) + r'\s*$', upload_text, re.M) is not None,
                   label + '.upload_exact_name', fatal=True)
        payload, zip_raw = self.archive(prefix + 'artifact-{}.zip'.format(artifact_id))
        digest = sha(zip_raw)
        self.equal(artifact.get('digest'), 'sha256:' + digest, label + '.api_zip_digest', fatal=True)
        self.equal(artifact.get('size_in_bytes'), len(zip_raw), label + '.api_zip_bytes', fatal=True)
        self.equal(uploaded_digests, [digest], label + '.upload_zip_digest', fatal=True)
        download = self.one([d for d in index.get('downloadedArtifacts', []) if d.get('artifactId') == artifact_id], label + '.download_index')
        self.equal(download.get('sha256'), digest, label + '.download_index_digest', fatal=True)
        self.equal(download.get('githubDigest'), artifact['digest'], label + '.download_index_api_digest', fatal=True)
        self.equal(download.get('name'), artifact_name, label + '.download_index_name', fatal=True)
        created = utc(artifact.get('created_at'))
        self.check(started <= created <= completed, label + '.artifact_created_in_this_job', fatal=True)
        capacity_raw, capacity_ref = self.backend_member(payload, 'advertising-capacity-receipt.json', label + '.capacity_receipt')
        capacity = json.loads(capacity_raw); identities = capacity.get('identities', {})
        publication = identities.get('publicationIdentity', {})
        expected = {'sourceHeadSha': self.args.head, 'testedMergeSha': self.merge,
                    'workflowRunId': str(run_id), 'workflowRunAttempt': str(attempt),
                    'workflowJob': job_name, 'artifactName': artifact_name}
        for key, value in expected.items():
            self.equal(publication.get(key), value, label + '.publicationIdentity.' + key, fatal=True)
        self.equal(identities.get('measuredLocalGitHead'), self.merge, label + '.measured_git_head', fatal=True)
        expected_ci = {'GITHUB_SHA': self.merge, 'GITHUB_REF': 'refs/pull/{}/merge'.format(self.pr_number),
                       'GITHUB_EVENT_NAME': 'pull_request', 'GITHUB_RUN_ID': str(run_id), 'GITHUB_RUN_ATTEMPT': str(attempt)}
        for key, value in expected_ci.items():
            self.equal(identities.get('ciIdentity', {}).get(key), value, label + '.ciIdentity.' + key, fatal=True)
        self.check(capacity.get('productionWriteEnabled') is False and capacity.get('realProviderAccess') is False,
                   label + '.capacity_declared_nonproduction', fatal=True)
        captured = utc(identities.get('datasetCapturedAt')); measure_start = utc(identities.get('startedAt'))
        measure_finish = utc(capacity.get('finishedAt'))
        self.check(started <= measure_start <= captured <= measure_finish <= completed,
                   label + '.capacity_times_inside_job', fatal=True)
        refs = {}
        for file_name, path_field, hash_field in [
            ('advertising-capacity-dataset.json', 'datasetPath', 'datasetSha256'),
            ('advertising-capacity-source-inputs.json', 'sourceInputsPath', 'sourceInputsSha256')]:
            self.equal(identities.get(path_field), 'target/' + file_name, label + '.' + path_field, fatal=True)
            raw, ref = self.backend_member(payload, file_name, label + '.' + file_name)
            self.equal(identities.get(hash_field), sha(raw), label + '.' + hash_field, fatal=True)
            refs[file_name] = (json.loads(raw), ref)
        self.equal(identities.get('runtimeResourceReceipt'), '../../build/slice3-runtime-resources.json',
                   label + '.resource_relative_path', fatal=True)
        resources_raw, resources_ref = self.member(payload, ['build/slice3-runtime-resources.json', 'slice3-runtime-resources.json'], label + '.runtime_resources')
        self.equal(identities.get('runtimeResourceReceiptSha256'), sha(resources_raw), label + '.resource_digest', fatal=True)
        resources = json.loads(resources_raw)
        for key, value in {'runId': str(run_id), 'runAttempt': str(attempt), 'job': job_name, 'testedCheckout': self.merge}.items():
            self.equal(resources.get('github', {}).get(key), value, label + '.resources.github.' + key, fatal=True)
        self.check(started <= utc(resources.get('recordedAt')) <= measure_start,
                   label + '.resource_capture_precedes_measurement_in_job', fatal=True)
        resource_lines, resource_log = self.job_log(logs, job_name, 'Record host and Docker resource limits')
        resource_objects = []
        for line in resource_lines:
            if line.startswith('{'):
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                if isinstance(obj, dict) and obj.get('schemaVersion') == '1.0' and 'docker' in obj:
                    resource_objects.append(obj)
        self.equal(resource_objects, [resources], label + '.resource_payload_equals_actual_capture_log', fatal=True)
        dataset, dataset_ref = refs['advertising-capacity-dataset.json']
        self.equal(dataset.get('datasetId'), identities.get('datasetId'), label + '.dataset_identity', fatal=True)
        source_manifest, source_ref = refs['advertising-capacity-source-inputs.json']
        self.check(isinstance(source_manifest, list), label + '.source_manifest_array', fatal=True)
        paths = [e.get('path') for e in source_manifest if isinstance(e, dict)]
        self.equal(len(paths), len(source_manifest), label + '.source_manifest_entry_shape', fatal=True)
        self.check(all(isinstance(p, str) and not PurePosixPath(p).is_absolute() and '..' not in PurePosixPath(p).parts and '\\' not in p for p in paths),
                   label + '.source_manifest_safe_paths', fatal=True)
        self.equal(len(paths), len(set(paths)), label + '.source_manifest_unique_paths', fatal=True)
        exact = self.source_git_bytes()
        missing = sorted(set(exact) - set(paths)); extra = sorted(set(paths) - set(exact))
        self.check(not missing and not extra, label + '.source_manifest_exact_input_set',
                   {'missing': missing, 'extra': extra}, {'missing': [], 'extra': []}, fatal=True)
        comparisons = []
        for entry in source_manifest:
            path = entry['path']; expected_blob = exact[path]
            valid = bool(SHA256.fullmatch(entry.get('sha256', ''))) and entry['sha256'] == expected_blob['sha256']
            comparisons.append({'path': path, 'manifestSha256': entry.get('sha256'),
                                **expected_blob, 'status': 'PASS' if valid else 'FAIL'})
        self.check(all(e['status'] == 'PASS' for e in comparisons), label + '.every_input_matches_exact_published_git_bytes',
                   {'entries': len(comparisons), 'mismatches': [e['path'] for e in comparisons if e['status'] != 'PASS']},
                   fatal=True)
        result.update({'status': 'PROVENANCE_PREDICATES_PASS', 'artifactId': artifact_id,
                       'artifactZipSha256': digest, 'artifactBytes': len(zip_raw), 'artifactApiCreatedAt': artifact['created_at'],
                       'uploadLog': upload_ref, 'capacityReceipt': capacity_ref, 'publicationIdentity': publication,
                       'dataset': dataset_ref, 'sourceManifest': source_ref, 'resourceReceipt': resources_ref,
                       'resourceCaptureLog': resource_log, 'exactPublishedSourceInputs': comparisons,
                       'measurement': {'startedAt': identities['startedAt'], 'capturedAt': identities['datasetCapturedAt'],
                                       'finishedAt': capacity['finishedAt'], 'measuredLocalGitHead': identities['measuredLocalGitHead']},
                       'semanticReviewRequired': 'This audit checks identity and bytes, not dataset representativeness, capacity SLO conclusions or all JUnit/coverage results.'})
        logs.close(); payload.close()

    def finish(self):
        stable = True
        for rel, item in list(self.inputs.items()):
            path = self.snapshot / rel
            now = {'path': rel, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} if path.is_file() else None
            if now != item:
                stable = False
                self.check(False, 'snapshot.input_stable', rel)
        self.check(stable, 'snapshot.all_consumed_files_stable')
        failures = [c for c in self.checks if c['status'] == 'FAIL']
        complete = len(self.results) == len(JOBS) and all(r.get('status') == 'PROVENANCE_PREDICATES_PASS' for r in self.results)
        self.report.update({'result': 'PROVENANCE_PREDICATES_PASS' if not failures and complete else 'FAIL',
                            'failureCount': len(failures), 'checks': self.checks, 'jobs': self.results,
                            'snapshotInputs': list(self.inputs.values()),
                            'controllerVerdict': 'NOT_ISSUED', 'findingClosure': 'NOT_ASSESSED', 'acceptanceCriteriaClosure': 'NOT_ASSESSED'})
        self.out.mkdir(parents=True, exist_ok=False)
        raw = (json.dumps(self.report, ensure_ascii=False, indent=2) + '\n').encode()
        destination = self.out / 'review.json'; destination.write_bytes(raw)
        (self.out / 'review.sha256').write_text(sha(raw) + '  review.json\n')
        print(json.dumps({'result': self.report['result'], 'report': str(destination),
                          'sha256': sha(raw), 'failureCount': len(failures)}))
        return 0 if self.report['result'] == 'PROVENANCE_PREDICATES_PASS' else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot', type=Path, required=True, help='Completed frozen collector output; never live target')
    parser.add_argument('--repo', type=Path, required=True, help='Repository containing exact published Head; only Git objects are read')
    parser.add_argument('--head', required=True)
    parser.add_argument('--base', default=BASE)
    parser.add_argument('--tested-merge', help='Optional additional exact expected PR test-merge SHA')
    parser.add_argument('--repository', default='Corwin-Code/marketops-platform')
    parser.add_argument('--out', type=Path, required=True, help='New output directory outside snapshot and Git repository')
    args = parser.parse_args()
    for name in ('head', 'base', 'tested_merge'):
        value = getattr(args, name)
        if value is not None and not SHA40.fullmatch(value):
            parser.error(name + ' must be a full lowercase 40-character Git object ID')
    try:
        audit = Audit(args)
    except Refused as exc:
        print(json.dumps({'result': 'FAIL', 'reason': str(exc)})); return 2
    try:
        audit.common()
    except (Refused, OSError, KeyError, TypeError, ValueError) as exc:
        audit.check(False, 'snapshot.required_common_evidence', type(exc).__name__ + ': ' + str(exc))
    else:
        for job, artifact in JOBS.items():
            try:
                audit.verify_job(job, artifact)
            except (Refused, OSError, KeyError, TypeError, ValueError, zipfile.BadZipFile) as exc:
                audit.check(False, job + '.required_evidence', type(exc).__name__ + ': ' + str(exc))
                if audit.results and audit.results[-1].get('job') == job:
                    audit.results[-1]['status'] = 'FAIL'
                    audit.results[-1]['reason'] = str(exc)
    return audit.finish()


if __name__ == '__main__':
    sys.exit(main())

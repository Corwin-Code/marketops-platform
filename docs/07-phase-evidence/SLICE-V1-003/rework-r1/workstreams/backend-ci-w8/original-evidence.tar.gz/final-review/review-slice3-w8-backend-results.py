#!/usr/bin/env python3
"""Read only completed archived CI artifacts. No live target, network, Git or tests."""
import argparse,datetime,hashlib,json,re,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--provenance',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
a.out.mkdir(exist_ok=False,parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def ref(path):
 b=path.read_bytes();return {'path':str(path),'sha256':sha(b),'bytes':len(b)}
def emit(name,v):
 b=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode();(a.out/name).write_bytes(b);return {'path':name,'sha256':sha(b),'bytes':len(b)}
provenance=json.loads(a.provenance.read_bytes());assert provenance['result']=='PROVENANCE_PREDICATES_PASS'
index=json.loads((a.snapshot/'run-job-artifact-index.json').read_bytes());run=next(r for r in index if r['runId']==33967874662)
runpath=a.snapshot/'runs'/'33967874662-attempt-1';logpath=runpath/'logs.zip'
report={'kind':'W8_BACKEND_CI_MEASURED_RESULTS_SEMANTIC_REVIEW','observedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'9b6e6195f779bd80b1e8ed9c78d6ad9daa1a68af','testedMerge':'954ff3617402c3ff22fa8eb86d9aa8abaea76941','runId':33967874662,'runAttempt':1,'reviewerBoundary':'Checks exact archived actual testcases, coverage and bounded capacity proof; does not approve 200 AC, 22 findings, new W9 frontend work, production or merge.','provenanceReview':ref(a.provenance),'jobs':[],'controllerVerdict':'NOT_ISSUED','findingClosure':'NOT_ASSESSED'}
allnodes=[];xmlrefs=[];checks=[]
for jobname,artifactname,stepname in [('backend-build','backend-test-reports','Run full backend verification and the combined coverage gate'),('backend-integration','backend-integration-reports','Run the database and application integration tests')]:
 artifact=next(v for v in run['downloadedArtifacts'] if v['name']==artifactname);zp=runpath/('artifact-'+str(artifact['artifactId'])+'.zip')
 j={'name':jobname,'artifact':ref(zp),'artifactId':artifact['artifactId'],'testGroups':{},'xmlInventory':[]}
 with zipfile.ZipFile(zp) as z:
  for group in ['surefire','failsafe']:
   names=sorted(n for n in z.namelist() if '/'+group+'-reports/TEST-' in n and n.endswith('.xml'))
   declared={'tests':0,'failures':0,'errors':0,'skipped':0};actual={'tests':0,'failures':0,'errors':0,'skipped':0};discrepancies=[]
   for name in names:
    raw=z.read(name);root=ET.fromstring(raw);ss=[root] if root.tag=='testsuite' else list(root.iter('testsuite'))
    totals={k:sum(int(s.get(k,'0')) for s in ss) for k in declared}
    for k in totals:declared[k]+=totals[k]
    tc=list(root.iter('testcase'));counts={'tests':len(tc),'failures':sum(t.find('failure') is not None for t in tc),'errors':sum(t.find('error') is not None for t in tc),'skipped':sum(t.find('skipped') is not None for t in tc)}
    for k in counts:actual[k]+=counts[k]
    r={'job':jobname,'group':group,'member':name,'sha256':sha(raw),'bytes':len(raw),'suiteDeclared':totals,'actualTestcases':counts};j['xmlInventory'].append(r);xmlrefs.append(r)
    if totals!=counts:discrepancies.append(r)
    for ordinal,t in enumerate(tc,1):
     nodes={'job':jobname,'group':group,'member':name,'xmlSha256':sha(raw),'ordinal':ordinal,'classname':t.get('classname'),'name':t.get('name'),'time':t.get('time'),'failure':t.find('failure') is not None,'error':t.find('error') is not None,'skipped':t.find('skipped') is not None}
     allnodes.append(nodes)
   j['testGroups'][group]={'uploaded':bool(names),'xmlCount':len(names),'suiteDeclared':declared,'actualTestcases':actual,'declaredVsActualDiscrepancies':discrepancies}
  summarynames=[n for n in z.namelist() if n.endswith('/failsafe-summary.xml')]
  assert len(summarynames)==1
  sr=z.read(summarynames[0]);s=ET.fromstring(sr)
  j['failsafeSummary']={'member':summarynames[0],'sha256':sha(sr),'rootAttributes':s.attrib,'values':{v.tag:v.text for v in s}}
  jacocos=[n for n in z.namelist() if n.endswith('/site/jacoco/jacoco.xml')]
  j['jacoco']={'uploaded':bool(jacocos),'boundary':'Build artifact uploads combined XML; integration artifact does not upload coverage XML, so that job coverage is substantiated by exact Maven verify output only.'}
  if jacocos:
   assert len(jacocos)==1;raw=z.read(jacocos[0]);r=ET.fromstring(raw);cs=[]
   for c in r.findall('counter'):
    miss=int(c.get('missed'));covered=int(c.get('covered'));cs.append({'type':c.get('type'),'missed':miss,'covered':covered,'ratio':covered/(miss+covered) if miss+covered else None})
   j['jacoco'].update({'member':jacocos[0],'sha256':sha(raw),'counters':cs,'requiredThresholds':{'LINE':.8,'BRANCH':.7}})
   for c in cs:
    if c['type'] in ['LINE','BRANCH']:checks.append({'rule':jobname+'.jacoco.'+c['type'],'pass':c['ratio']>={'LINE':.8,'BRANCH':.7}[c['type']]})
  for key,end in [('capacity','advertising-capacity-receipt.json'),('dataset','advertising-capacity-dataset.json'),('resource','slice3-runtime-resources.json')]:
   ns=[n for n in z.namelist() if n.endswith('/'+end) or n==end];assert len(ns)==1
   raw=z.read(ns[0]);j[key]={'member':ns[0],'sha256':sha(raw),'data':json.loads(raw)}
 with zipfile.ZipFile(logpath) as z:
  ns=[n for n in z.namelist() if re.fullmatch(re.escape(jobname)+r'/\d+_'+re.escape(stepname)+r'\.txt',n)];assert len(ns)==1
  raw=z.read(ns[0]);lines=raw.decode('utf-8-sig').splitlines()
  selected=[];totals=[]
  for ordinal,line in enumerate(lines,1):
   if any(x in line for x in ['Tests run:','BUILD SUCCESS','BUILD FAILURE','All coverage checks have been met','Rule violated for bundle','Total time:','Finished at:','./mvnw','jacoco-maven-plugin:','maven-failsafe-plugin:','maven-surefire-plugin:']):
    if 'Tests run:' not in line or re.search(r'Skipped: \d+\s*$',line):selected.append({'line':ordinal,'text':line})
   m=re.search(r'\[INFO\] Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+)\s*$',line)
   if m:totals.append(dict(zip(['tests','failures','errors','skipped'],map(int,m.groups()))))
  j['mavenLog']={'member':ns[0],'sha256':sha(raw),'bytes':len(raw),'actualRelevantLines':selected,'consoleAggregateCounts':totals,'buildSuccess':any('[INFO] BUILD SUCCESS' in l for l in lines),'buildFailure':any('[INFO] BUILD FAILURE' in l for l in lines),'coverageCheckPassed':any('All coverage checks have been met' in l for l in lines)}
  checks.extend([{'rule':jobname+'.maven.success','pass':j['mavenLog']['buildSuccess'] and not j['mavenLog']['buildFailure']},{'rule':jobname+'.coverage.consolePassed','pass':j['mavenLog']['coverageCheckPassed']}])
  assert len(totals)==2
  for group,console in zip(['surefire','failsafe'],totals):
   j['testGroups'][group]['mavenConsoleCounts']=console
   if j['testGroups'][group]['uploaded']:
    checks.append({'rule':jobname+'.'+group+'.consoleEqualsActualNodes','pass':console==j['testGroups'][group]['actualTestcases']})
   else:j['testGroups'][group]['rawXmlBoundary']='Not uploaded by this exact workflow job. No independent per-node claim; count from main full verify console.'
  if jobname=='backend-build':
   j['extraVerificationSteps']=[]
   for label in ['Prove the backend coverage gate rejects an unmet threshold','Verify packaged migration resolver and isolated runtime artifacts']:
    nn=[n for n in z.namelist() if re.fullmatch(re.escape(jobname)+r'/\d+_'+re.escape(label)+r'\.txt',n)];assert len(nn)==1
    bb=z.read(nn[0]);j['extraVerificationSteps'].append({'name':label,'member':nn[0],'sha256':sha(bb),'bytes':len(bb),'tail':bb.decode(errors='replace').splitlines()[-12:]})
 j['capacityProofBoundary']={'scenario':'1000 UNVERIFIED native advertising objects, one organization/store and one shared product/listing; real targeted calculation, projection, responsibility Task, brief and reconciliation paths; synthetic containment creates additional protection tasks.','limits':['The measured command count is asserted zero; this is not Provider write or command throughput.','The 1000-object case does not measure mature Outcome evaluation throughput; actual scoped Outcome correctness has separate smaller named integration tests.','This is not a multi-store/high-cardinality/full verified-Optimization mix benchmark.','An initial targeted snapshot can record hourly reconciliation not current before the subsequent measured sweep; do not erase or relabel that transient snapshot.'],'measurementUnits':'Milliseconds; accepted P95 <=300000 and hardmax <=900000; hourly margin >0.','noSemanticAutoPromotion':True}
 report['jobs'].append(j)
checks.append({'rule':'uploadedActualCases.noFailureErrorSkipped','pass':all(not n['failure'] and not n['error'] and not n['skipped'] for n in allnodes)})
report['checks']=checks;report['result']='ACTUAL_RESULTS_REVIEW_PASS_WITH_EXPLICIT_EVIDENCE_LIMITS' if all(c['pass'] for c in checks) else 'ACTUAL_RESULTS_REVIEW_FAILED'
report['outputs']=[emit('actual-testcase-index.json',allnodes),emit('raw-xml-index.json',xmlrefs)]
report['inputs']=[ref(a.snapshot/'receipt.json'),ref(a.snapshot/'run-job-artifact-index.json'),ref(logpath),ref(Path(__file__))]
r=emit('review.json',report);print(json.dumps({'result':report['result'],'report':r,'checks':len(checks),'failedChecks':[c for c in checks if not c['pass']]}))
raise SystemExit(0 if all(c['pass'] for c in checks) else 2)

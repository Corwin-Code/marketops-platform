"""Read exact Draft PR/check/run/attempt/artifact identities. No GitHub mutation."""
import argparse, concurrent.futures, datetime, hashlib, json, pathlib, re, subprocess, time, urllib.parse, zipfile

REPO = 'Corwin-Code/marketops-platform'
BRANCH = 'feat/SLICE-V1-003-advertising-traffic-efficiency'
BASE = '08ad7da7d9e75b4ddd1c387a22ac0affba9e1430'
REQUIRED = ['governance','backend-build','architecture-boundary','backend-integration','frontend-lint','frontend-typecheck','frontend-test','frontend-build','dependency-review','codeql-java','codeql-typescript','infrastructure-validation']
p=argparse.ArgumentParser();p.add_argument('--pr',type=int,required=True);p.add_argument('--head',required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--download',action='store_true');a=p.parse_args()
assert re.fullmatch('[0-9a-f]{40}',a.head)
a.out.mkdir(parents=True,exist_ok=False)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(path,binary=False):
    for attempt in range(3):
        r=subprocess.run(['gh','api',f'repos/{REPO}/{path}'],capture_output=True)
        if r.returncode==0:return r.stdout if binary else json.loads(r.stdout)
        if attempt<2:time.sleep(1)
    raise RuntimeError('GitHub read failed for '+path+': '+r.stderr.decode()[:600])
def save(name,data):
    path=a.out/name;path.parent.mkdir(parents=True,exist_ok=True)
    raw=data if isinstance(data,bytes) else (json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
    path.write_bytes(raw);return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
def pages(path,key):
    result=[]
    for n in range(1,50):
        v=api(path+('&' if '?' in path else '?')+f'per_page=100&page={n}');items=v[key] if key else v
        result.extend(items)
        if len(items)<100:return result
    raise RuntimeError('Unexpected pagination beyond bounded repository scope')

started=now();pr=api(f'pulls/{a.pr}');save('pr.json',pr)
boundaries={'sameRepository':pr['head']['repo']['full_name']==REPO,'sameBranch':pr['head']['ref']==BRANCH,'exactHead':pr['head']['sha']==a.head,'exactBase':pr['base']['sha']==BASE,'draft':pr['draft'] is True,'open':pr['state']=='open','unmerged':pr['merged'] is False,'noAutoMerge':pr.get('auto_merge') is None}
if not all(boundaries.values()):
    save('receipt.json',{'startedAt':started,'boundaries':boundaries,'result':'IDENTITY_OR_AUTHORITY_BOUNDARY_REFUSED'});raise SystemExit(3)
checks=pages(f'commits/{a.head}/check-runs','check_runs');save('check-runs.json',checks)
latest={}
for check in checks:
    if check['name'] in REQUIRED and check.get('app',{}).get('id')==15368:
        previous=latest.get(check['name'])
        if previous is None or check['id']>previous['id']:latest[check['name']]=check
summary={name:({'id':latest[name]['id'],'status':latest[name]['status'],'conclusion':latest[name]['conclusion'],'headSha':latest[name]['head_sha'],'detailsUrl':latest[name]['details_url']} if name in latest else {'status':'MISSING'}) for name in REQUIRED}
additional_latest={}
for check in checks:
    if check['name'] not in REQUIRED:
        key=(check['name'],check.get('app',{}).get('id'))
        if key not in additional_latest or check['id']>additional_latest[key]['id']:additional_latest[key]=check
additional_summary=[{'name':c['name'],'id':c['id'],'appId':c.get('app',{}).get('id'),'appSlug':c.get('app',{}).get('slug'),'status':c['status'],'conclusion':c['conclusion'],'headSha':c['head_sha'],'detailsUrl':c.get('details_url'),'title':c.get('output',{}).get('title')} for c in additional_latest.values()]
aggregate_codeql=[c for c in additional_summary if c['name']=='CodeQL']
aggregate_codeql_pass=len(aggregate_codeql)==1 and aggregate_codeql[0]['status']=='completed' and aggregate_codeql[0]['conclusion']=='success' and aggregate_codeql[0]['headSha']==a.head
additional_pass=all(c['status']=='completed' and c['conclusion']=='success' and c['headSha']==a.head for c in additional_summary)
runs=pages('actions/runs?'+urllib.parse.urlencode({'event':'pull_request','head_sha':a.head}),'workflow_runs');save('workflow-runs.json',runs)
run_ids={int(m.group(1)) for c in latest.values() if (m:=re.search(r'/actions/runs/(\d+)',c.get('details_url','')))}
def collect_run(run_id):
    run=api(f'actions/runs/{run_id}');attempt=run['run_attempt'];prefix=f'runs/{run_id}-attempt-{attempt}'
    jobs=pages(f'actions/runs/{run_id}/attempts/{attempt}/jobs','jobs');artifacts=pages(f'actions/runs/{run_id}/artifacts','artifacts')
    save(prefix+'/run.json',run);save(prefix+'/jobs.json',jobs);save(prefix+'/artifacts.json',artifacts)
    result={'runId':run_id,'attempt':attempt,'headSha':run['head_sha'],'url':run['html_url'],'name':run['name'],'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':j['id'],'name':j['name'],'headSha':j.get('head_sha'),'status':j['status'],'conclusion':j['conclusion'],'url':j['html_url'],'startedAt':j['started_at'],'completedAt':j['completed_at']} for j in jobs],'artifacts':[{'id':v['id'],'name':v['name'],'digest':v.get('digest'),'expired':v['expired'],'sizeBytes':v['size_in_bytes']} for v in artifacts]}
    if a.download and run['status']=='completed':
        raw=api(f'actions/runs/{run_id}/attempts/{attempt}/logs',True);result['logArchive']=save(prefix+'/logs.zip',raw)
        with zipfile.ZipFile(a.out/prefix/'logs.zip') as z:
            refs=[]
            for name in z.namelist():
                if name.endswith('.txt'):
                    text=z.read(name).decode(errors='replace')
                    for match in re.finditer(r'(?:git log -1 --format=.*?\n)([^\n]*)',text):
                        hashes=re.findall(r'\b[0-9a-f]{40}\b',match.group(1))
                        if hashes:refs.append({'logMember':name,'sha':hashes[-1],'basis':'Actual checkout git log -1 output'})
            result['checkoutCommitObservations']=refs
        downloads=[]
        for artifact in artifacts:
            if artifact['expired']:continue
            raw=api(f"actions/artifacts/{artifact['id']}/zip",True)
            item=save(prefix+f"/artifact-{artifact['id']}.zip",raw);item.update({'artifactId':artifact['id'],'name':artifact['name'],'githubDigest':artifact.get('digest')});downloads.append(item)
        result['downloadedArtifacts']=downloads
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as workers:details=list(workers.map(collect_run,sorted(run_ids)))
save('run-job-artifact-index.json',details)
all_green=len(latest)==12 and all(c['status']=='completed' and c['conclusion']=='success' and c['head_sha']==a.head for c in latest.values())
merge=pr.get('merge_commit_sha');merge_record=None
if merge:
    commit=api('git/commits/'+merge);merge_record={'sha':commit['sha'],'tree':commit['tree']['sha'],'parents':[v['sha'] for v in commit['parents']]};save('pr-tested-merge-current.json',merge_record)
end_pr=api(f'pulls/{a.pr}');save('pr-final-readback.json',end_pr)
final_boundaries={'sameRepository':end_pr['head']['repo']['full_name']==REPO,'sameBranch':end_pr['head']['ref']==BRANCH,'exactHead':end_pr['head']['sha']==a.head,'exactBase':end_pr['base']['sha']==BASE,'draft':end_pr['draft'] is True,'open':end_pr['state']=='open','unmerged':end_pr['merged'] is False,'noAutoMerge':end_pr.get('auto_merge') is None}
stable=all(final_boundaries.values())
result={'kind':'READ_ONLY_EXACT_DRAFT_PR_CI_SNAPSHOT','startedAt':started,'finishedAt':now(),'repository':REPO,'pr':a.pr,'prUrl':pr['html_url'],'sourceHead':a.head,'boundaries':boundaries,'headAndDraftStable':stable,'finalBoundaries':final_boundaries,'provenanceReview':'Raw collection only. Every latest-attempt job, actual tested checkout commit and parents/tree, artifact attempt/source binding, downloaded bytes and publicationIdentity must be assessed separately. Check-context success is not that assessment.','requiredContexts':summary,'allTwelveRequiredChecksSuccess':all_green,'additionalCurrentChecks':additional_summary,'aggregateCodeQLCheckSuccess':aggregate_codeql_pass,'allObservedAdditionalChecksSuccess':additional_pass,'currentPrMerge':merge_record,'mergeParentsMatchExactBaseAndHead':bool(merge_record and merge_record['parents']==[BASE,a.head]),'runCount':len(details),'downloadRequested':a.download,'controllerVerdict':'NOT_ISSUED_BY_CODEX','productionWriteEnabled':False,'result':'ALL_CHECK_CONTEXTS_PASS_PROVENANCE_REVIEW_PENDING' if all_green and stable and aggregate_codeql_pass and additional_pass else 'PENDING_OR_FAILED'}
save('receipt.json',result);print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if all_green and stable and aggregate_codeql_pass and additional_pass else 2)

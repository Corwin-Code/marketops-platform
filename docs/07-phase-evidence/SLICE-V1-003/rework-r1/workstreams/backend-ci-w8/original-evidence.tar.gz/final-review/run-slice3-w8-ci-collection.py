from pathlib import Path
import subprocess,datetime,json,hashlib
script=Path('/tmp/collect-slice3-pr-ci.py');out=Path('/tmp/slice3-pr30-w8-complete-ci');assert not out.exists()
argv=['python3',str(script),'--pr','30','--head','9b6e6195f779bd80b1e8ed9c78d6ad9daa1a68af','--out',str(out),'--download']
meta={'argv':argv,'cwd':'/tmp','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'collectorScriptSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'boundary':'Read-only GitHub API/download; stderr preserved privately and not echoed because transport errors can contain signed URLs.'}
Path('/tmp/slice3-w8-ci-collector-command-start.json').write_text(json.dumps(meta,indent=2)+'\n')
with open('/tmp/slice3-w8-ci-collector.stdout.private.log','wb') as stdout,open('/tmp/slice3-w8-ci-collector.stderr.private.log','wb') as stderr:
 p=subprocess.run(argv,cwd='/tmp',stdout=stdout,stderr=stderr)
meta.update({'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode})
for key,fn in [('stdout','/tmp/slice3-w8-ci-collector.stdout.private.log'),('stderr','/tmp/slice3-w8-ci-collector.stderr.private.log')]:
 b=Path(fn).read_bytes();meta[key]={'path':fn,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
Path('/tmp/slice3-w8-ci-collector-command-complete.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
raise SystemExit(p.returncode)

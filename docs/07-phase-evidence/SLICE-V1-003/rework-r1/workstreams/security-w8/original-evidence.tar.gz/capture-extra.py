from pathlib import Path
import datetime,json,os,subprocess,sys
name,mode,value=sys.argv[1:];out=Path('/tmp/slice3-security-w8');env=dict(os.environ);env['XDG_CACHE_HOME']=str(out/'gh-cache')
argv=['gh','api','--include','-H','Accept: application/sarif+json','repos/Corwin-Code/marketops-platform/code-scanning/analyses/'+value] if mode=='sarif' else ['gh','run','view',value,'--repo','Corwin-Code/marketops-platform','--log']
start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,capture_output=True,env=env)
file=out/(name+('.response.txt' if mode=='sarif' else '.log'));file.write_bytes(p.stdout);(out/(name+'.stderr.txt')).write_bytes(p.stderr)
meta={'argv':argv,'startedAtUTC':start,'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'stdoutBytes':len(p.stdout),'stderrBytes':len(p.stderr)}
if mode=='sarif':
 raw=p.stdout.decode().replace('\r\n','\n');meta['httpStatus']=raw.splitlines()[0]if raw else None
 try:(out/(name+'.json')).write_text(json.dumps(json.loads(raw.split('\n\n',1)[-1]),indent=2)+'\n')
 except Exception:pass
(out/(name+'.request.json')).write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))

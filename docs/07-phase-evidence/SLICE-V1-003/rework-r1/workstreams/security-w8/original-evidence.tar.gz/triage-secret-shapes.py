from pathlib import Path
import ast,json,re,hashlib,datetime
p=Path('/tmp/slice3-security-w8');root=Path('/Users/chzhengx/Code/personal/marketops-platform');sha=lambda b:hashlib.sha256(b).hexdigest()
priorScript=Path('/tmp/triage-slice3-w6-w7-sarif-secret-shapes.py');priorReview=Path('/tmp/slice3-w6-w7-secret-triage/review.json')
# Reuse the exact previous read-only JSON token-span and metadata traversal.
scriptTree=ast.parse(priorScript.read_text());selected=[n for n in scriptTree.body if isinstance(n,ast.FunctionDef)and n.name in ['token_spans','redact','rule_metadata']]
rulefile=root/'scripts/validate_governance.py';tree=ast.parse(rulefile.read_text());expr=next(n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='SECRET_PATTERNS'for t in n.targets));patterns=eval(compile(ast.Expression(expr),'repository-patterns','eval'),{'re':re});patterns.append(re.compile(r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b'))
exec(compile(ast.Module(body=selected,type_ignores=[]),str(priorScript),'exec'))
scan=json.loads((p/'publishability-scan.json').read_text());assert scan['pass'] is False and len(scan['findings'])==2
prior=json.loads(Path('/tmp/slice3-security-w7/typescript-w7.sarif.json').read_text());priorobj=prior
rows=[]
def pointer(obj,path):
 for part in path.split('/')[1:]:obj=obj[int(part)]if isinstance(obj,list)else obj[part.replace('~1','/').replace('~0','~')]
 return obj
for f in scan['findings']:
 assert f['patternIndex']==6 and f['count']==4
 file=Path(f['path']);raw=file.read_bytes();text=raw.decode();start=text.find('{');obj=json.loads(text[start:]);spans=token_spans(text,start);rawhits=[];decoded=[]
 assert obj['runs'][0]['tool']['extensions']==prior['runs'][0]['tool']['extensions']
 for m in patterns[6].finditer(text):
  s=next(s for s in spans if s['start']<=m.start()and m.end()<=s['end']);meta=rule_metadata(obj,s['pointer']);assert meta['sarifRuleId']=='js/session-fixation'
  assert pointer(prior,s['pointer'])==s['value']
  rawhits.append({'rawLine':text.count('\n',0,m.start())+1,'rawByteOffset':len(text[:m.start()].encode()),'sarifJsonPointer':s['pointer'],**meta,'classification':'STATIC_CODEQL_RULE_HELP_EXAMPLE_NOT_APPLICATION_SECRET','exactPriorHelpValueSha256':sha(s['value'].encode()),'sameExactReviewedW7Help':True,'sanitizedContext':redact(text[max(s['start'],m.start()-55):m.start()])+'[MATCH REDACTED]'+redact(text[m.end():min(s['end'],m.end()+55)]),'safeToPublishUnchanged':True})
 for s in spans:
  hits=list(patterns[6].finditer(s['value']))
  if not hits:continue
  meta=rule_metadata(obj,s['pointer']);assert meta['sarifRuleId']in ['js/session-fixation','js/jwt-missing-verification'];assert pointer(prior,s['pointer'])==s['value']
  decoded.append({'sarifJsonPointer':s['pointer'],**meta,'decodedCount':len(hits),'sameExactReviewedW7Help':True,'decodedHelpValueSha256':sha(s['value'].encode()),'classification':'STATIC_CODEQL_RULE_HELP_EXAMPLE_NOT_APPLICATION_SECRET'})
 results=obj['runs'][0].get('results',[]);assert all(not pat.search(json.dumps(results))for pat in patterns)
 rows.append({'path':file.name,'rawSha256':sha(raw),'bytes':len(raw),'rawHits':rawhits,'decodedHelpMatches':decoded,'sarifResultCount':len(results),'matchesInResults':0,'safeToPublishOriginalUnchanged':True})
review={'kind':'W8_EXACT_SARIF_SECRET_SHAPE_FALSE_POSITIVE_TRIAGE','recordedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalScan':{'path':'publishability-scan.json','sha256':sha((p/'publishability-scan.json').read_bytes()),'pass':False,'retainedUnmodified':True},'patternAuthority':{'path':'scripts/validate_governance.py','sha256':sha(rulefile.read_bytes())},'methodReuse':{'priorScript':str(priorScript),'sha256':sha(priorScript.read_bytes()),'priorReview':str(priorReview),'priorReviewSha256':sha(priorReview.read_bytes()),'selectedFunctions':['token_spans','redact','rule_metadata']},'reviewedRawOccurrences':8,'reviewedFiles':2,'safeToPublishTheseOriginalSarifFiles':True,'findings':rows,'matchedValuesPrintedOrSaved':False,'scope':'All eight raw hits are in bundled static CodeQL rule help; decoded illustrative examples are also compared exactly with previously reviewed W7 help. No hit is in SARIF application results or actual runtime credentials. Original scan pass=false and API bytes remain unchanged.'}
(p/'secret-shape-triage.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'triageSha256':sha((p/'secret-shape-triage.json').read_bytes()),'rawOccurrences':8,'safe':True},indent=2))

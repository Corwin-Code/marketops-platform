from pathlib import Path
import json,hashlib,datetime,collections,subprocess,base64
p=Path('/tmp/slice3-security-w8');oldp=Path('/tmp/slice3-security-w7');root=Path('/Users/chzhengx/Code/personal/marketops-platform')
read=lambda n:json.loads((p/n).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();write=lambda n,x:(p/n).write_text(json.dumps(x,indent=2)+'\n')
head='9b6e6195f779bd80b1e8ed9c78d6ad9daa1a68af';oldhead='3e4039259c0a56d0f10319cdcae79cab66f81983';base='08ad7da7d9e75b4ddd1c387a22ac0affba9e1430';merge='954ff3617402c3ff22fa8eb86d9aa8abaea76941'
run=read('security-run-poll2.json');jobs=read('security-jobs-poll2.json')['jobs'];analyses=[a for a in read('analyses-poll2.json')if a['commit_sha']==merge];check=next(a for a in read('checks-head-poll2.json')['check_runs']if a['name']=='CodeQL')
assert run['head_sha']==head and run['conclusion']=='success'and run['run_attempt']==1
assert len(jobs)==3 and all(a['conclusion']=='success'for a in jobs)
assert len(analyses)==2 and all(a['tool']['version']=='2.26.4'and not a['error']for a in analyses)
assert check['conclusion']=='success'and check['output']['annotations_count']==87
mergeinfo=read('merge-w8.json');assert [x['sha']for x in mergeinfo['parents']]==[base,head]
assert mergeinfo['tree']['sha']=='eb4bce1333c87e4de762f6f42bbd3bcd392fec38'
tree=read('tree-w8.json');assert not tree['truncated'];blobs={x['path']:x['sha']for x in tree['tree']};comparison=read('compare-w7-w8.json')
old={a['number']:a for a in json.loads((oldp/'alerts-open-final.json').read_text())};new={a['number']:a for a in read('alerts-open-final.json')};fixed=read('alerts-fixed-final.json');dismissed=read('alerts-dismissed-final.json')
assert len(new)==87 and set(old)==set(new) and {a['number']for a in fixed}==set(range(118,130))
assert {a['number']for a in dismissed}=={66,73,74,75,76}
assert not[a for a in new.values()if a['rule'].get('security_severity_level')]
cache={}
def source(commit,path):
 key=(commit,path)
 if key not in cache:cache[key]=subprocess.check_output(['/usr/bin/git','show',commit+':'+path],cwd=root)
 return cache[key]
def expr(raw,loc):
 lines=raw.decode().splitlines();first=loc['start_line']-1;last=loc['end_line']-1
 if first==last:return lines[first][loc['start_column']-1:loc['end_column']-1]
 return '\n'.join([lines[first][loc['start_column']-1:]]+lines[first+1:last]+[lines[last][:loc['end_column']-1]])
rows=[]
for num,a in sorted(new.items()):
 b=old[num];loc=a['most_recent_instance']['location'];prior=b['most_recent_instance']['location'];path=loc['path']
 assert a['rule']['id']==b['rule']['id']and a['rule'].get('security_severity_level')==b['rule'].get('security_severity_level')and a['most_recent_instance']['commit_sha']==merge
 before=source(oldhead,prior['path']);after=source(head,path);actualblob=subprocess.check_output(['/usr/bin/git','rev-parse',head+':'+path],cwd=root,text=True).strip();assert actualblob==blobs[path]
 expressionSame=expr(before,prior)==expr(after,loc);assert expressionSame,(num,path)
 rows.append({'number':num,'ruleId':a['rule']['id'],'securitySeverity':a['rule'].get('security_severity_level'),'level':a['rule']['severity'],'state':'open','priorLocation':prior,'currentLocation':loc,'locationMoved':prior!=loc,'sameExactFlaggedExpression':expressionSame,'priorSourceSha256':sha(before),'currentSourceSha256':sha(after),'currentRemoteGitBlob':blobs[path],'sameWholeFile':before==after,'currentMergeSha':merge,'priorTriage':'docs/07-phase-evidence/SLICE-V1-003/rework-r1/workstreams/security-w6 (original 99-to-87 per-alert triage)','engineeringAssessment':'Same warning/note and same exact flagged expression. W8 changes address time precision, capacity oracle and test isolation; earlier bounded quality triage remains applicable. No dismissal or accepted-criterion promotion is performed.'})
raw=[]
for n in ['java-w8.sarif.json','typescript-w8.sarif.json']:
 for r in read(n)['runs']:
  for a in r.get('results',[]):raw.append({'number':a['properties']['github/alertNumber'],'ruleId':a['ruleId'],'level':a['level'],'file':n})
assert len(raw)==92 and {x['number']for x in raw}==set(new)|{66,73,74,75,76}
oldDismissed={a['number']:a for a in json.loads((oldp/'alerts-dismissed-final.json').read_text())};legacy=[]
for a in dismissed:
 prior=oldDismissed[a['number']];assert all(a.get(k)==prior.get(k)for k in ['dismissed_at','dismissed_reason','dismissed_comment'])
 path=a['most_recent_instance']['location']['path'];rawBase=source(base,path);rawW7=source(oldhead,path);rawW8=source(head,path);assert rawBase==rawW7==rawW8
 legacy.append({'number':a['number'],'ruleId':a['rule']['id'],'securitySeverity':a['rule']['security_severity_level'],'path':path,'baseSourceSha256':sha(rawBase),'w7SourceSha256':sha(rawW7),'w8SourceSha256':sha(rawW8),'sourceIdenticalToBase':True,**{k:a.get(k)for k in ['state','dismissed_at','dismissed_reason','dismissed_comment']}})
lock=(p/'lock-w8.decoded.json').read_bytes();assert sha(lock)=='6e2751b0187c16ac884ddc5584e2cd4f78fc3abd7a401a98388bc9334e0f8ea4'
dep=read('dependencies-w8.json');added=next(x for x in dep if x['change_type']=='added');removed=next(x for x in dep if x['change_type']=='removed');assert added['name']=='fast-uri'and added['version']=='3.1.6'and not added['vulnerabilities']and removed['version']=='3.1.5'and len(removed['vulnerabilities'])==4
main=read('dependabot-main-final.json');assert len(main)==4 and all(x['state']=='open'and x['security_advisory']['severity']=='high'for x in main)
fixedProof=[{'number':x['number'],'state':x['state'],'ruleId':x['rule']['id'],'securitySeverity':x['rule']['security_severity_level'],'notPresentInExactCurrentSarif':x['number']not in {a['number']for a in raw}}for x in sorted(fixed,key=lambda a:a['number'])]
summary={'kind':'W8_EXACT_HEAD_SECURITY_READBACK','generatedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'Corwin-Code/marketops-platform','pullRequest':30,'head':head,'tree':mergeinfo['tree']['sha'],'testedMerge':merge,'mergeParents':[base,head],'securityRun':{k:run[k]for k in ['id','run_attempt','head_sha','event','status','conclusion','created_at','updated_at','html_url']},'jobs':[{k:a[k]for k in ['id','name','status','conclusion','started_at','completed_at','html_url']}for a in jobs],'aggregateCodeQL':{k:check[k]for k in ['id','name','status','conclusion','started_at','completed_at','output','html_url']},'analyses':analyses,'fixedSecurityAlerts':fixedProof,'openAlerts':{'priorCount':87,'currentCount':87,'addedNumbers':[],'removedNumbers':[],'currentOpenSecuritySeverityCount':0,'movedOriginalLocations':[a['number']for a in rows if a['locationMoved']],'groups':[{'ruleId':k[0],'level':k[1],'securitySeverity':k[2],'count':v}for k,v in sorted(collections.Counter((a['ruleId'],a['level'],a['securitySeverity'])for a in rows).items())],'perAlertProof':'w7-w8-alert-delta.json'},'rawSarifResults':raw,'historicalDismissedSecurity':legacy,'lockSha256':sha(lock),'dependencyGraphComparison':dep,'defaultMainOpenHighDependabotCount':len(main),'actionsArtifacts':read('security-artifacts-final.json'),'changedNonEvidencePaths':[x['filename']for x in comparison['files']if not x['filename'].startswith('docs/07-phase-evidence/')],'assessment':'Exact W8 Security workflow and all three jobs succeeded, and aggregate CodeQL independently succeeded after Java configuration arrived. The 12 repaired security alerts remain fixed; all 87 remaining warning/note expressions are exactly unchanged, with no new alert or security severity. Five legacy false-positive HIGH dismissals remain in raw SARIF, unchanged and with source identical to Base. Branch fast-uri3.1.6 still resolves four HIGH advisories, while default-main alerts remain open.','limits':['Initial neutral aggregate response is preserved, not overwritten.','Security alone does not close AC200, all engineering criteria, full Backend/browser CI, or confer Controller approval.','No source/lock edits, workflow reruns, alert dismissals, provider IO, credentials provisioning or live full-run XML reads occurred.','No Actions artifact is published by this workflow; original SARIF API responses and complete job log are saved directly.']}
write('summary.json',summary);write('w7-w8-alert-delta.json',{'head':head,'merge':merge,'oldHead':oldhead,'alerts':rows});write('source-identity.json',{'head':head,'tree':mergeinfo['tree']['sha'],'testedMerge':merge,'parents':[base,head],'remoteTreeTruncated':False,'changedPaths':[x['filename']for x in comparison['files']],'lockSha256':sha(lock),'priorTriageExpressionMatches':len(rows),'priorTriageWholeFileMatches':sum(a['sameWholeFile']for a in rows),'securityWorkflowGitBlob':blobs['.github/workflows/security.yml']})
print(json.dumps({'summarySha256':sha((p/'summary.json').read_bytes()),'deltaSha256':sha((p/'w7-w8-alert-delta.json').read_bytes()),'sameExpressions':len(rows),'sameFiles':sum(a['sameWholeFile']for a in rows),'moved':sum(a['locationMoved']for a in rows)},indent=2))

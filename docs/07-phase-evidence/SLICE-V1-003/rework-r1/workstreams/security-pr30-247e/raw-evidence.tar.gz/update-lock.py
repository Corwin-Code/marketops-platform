from pathlib import Path
import subprocess,os,json,datetime,hashlib
out=Path('/tmp/slice3-security-default-alert-review');cwd=Path('/Users/chzhengx/Code/personal/marketops-platform/frontend/marketops-console');env=os.environ.copy();env['PATH']='/Users/chzhengx/Library/Application Support/fnm/node-versions/v24.19.0/installation/bin:'+env['PATH']
lock=cwd/'package-lock.json';before=lock.read_bytes();package_before=(cwd/'package.json').read_bytes();(out/'lock-before-update.json').write_bytes(before)
assert json.loads(before)['packages']['node_modules/fast-uri']['version']=='3.1.5'
for id in ['GHSA-jqff-g426-hqxp','GHSA-f65p-4m7j-42xc','GHSA-fph4-wmhf-6fwf','GHSA-5jgf-p345-68v8']:
 a=json.loads((out/('advisory-'+id+'.json')).read_text());assert a['withdrawn_at'] is None
 lines=[v for v in a['vulnerabilities'] if v['package']['ecosystem']=='npm' and v['package']['name']=='fast-uri' and v['first_patched_version']=='3.1.6']
 assert len(lines)==1,(id,lines)
args=['npm','update','fast-uri','--package-lock-only','--ignore-scripts','--no-audit','--no-fund','--registry=https://registry.npmjs.org','--cache='+str(out/'npm-cache')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(args,cwd=cwd,env=env,capture_output=True)
(out/'npm-update.stdout.txt').write_bytes(r.stdout);(out/'npm-update.stderr.txt').write_bytes(r.stderr)
meta={'argv':args,'cwd':str(cwd),'startedAtUTC':start,'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'runtime':json.loads((out/'npm-runtime.json').read_text())}
(out/'npm-update.request.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
if r.returncode!=0:raise SystemExit('npm update failed; inspect saved output')
a=json.loads(before);b=json.loads(lock.read_bytes());changes=[k for k in set(a['packages'])|set(b['packages']) if a['packages'].get(k)!=b['packages'].get(k)]
assert changes==['node_modules/fast-uri'],changes
assert {k:v for k,v in a.items() if k!='packages'}=={k:v for k,v in b.items() if k!='packages'}
assert (cwd/'package.json').read_bytes()==package_before
assert b['packages']['node_modules/fast-uri']['version']=='3.1.6'
registry=json.loads((out/'npm-fast-uri-3.1.6.json').read_text());node=b['packages']['node_modules/fast-uri'];assert node['integrity']==registry['dist']['integrity'] and node['resolved']==registry['dist']['tarball']
(out/'lock-after-update.json').write_bytes(lock.read_bytes());print('EXACT_CHANGED_NODES',changes);print('NEW_NODE',node)
receipt={'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(lock.read_bytes()).hexdigest(),'packageJsonUnchanged':True,'changedPackageNodes':changes,'oldNode':a['packages']['node_modules/fast-uri'],'newNode':node,'matchesPrimaryRegistryIntegrityAndTarball':True}
(out/'lock-update-scope.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)

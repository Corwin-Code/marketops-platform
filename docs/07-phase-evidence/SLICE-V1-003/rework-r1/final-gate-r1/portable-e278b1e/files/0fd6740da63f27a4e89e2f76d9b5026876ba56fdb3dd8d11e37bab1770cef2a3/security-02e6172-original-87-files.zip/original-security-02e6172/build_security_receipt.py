from pathlib import Path
import collections,datetime,hashlib,json,re,subprocess,zipfile
ROOT=Path('/Users/chzhengx/Code/personal/marketops-platform');OUT=Path(__file__).resolve().parent
HEAD='02e617278793b4458dfb7cac74c2a937f1dfcb00';TREE='8d8dd0b3429797a0e01b2ff91c1ba5c09de17dcc';MERGE='2b3e8e4b60f4d7a22afe1616f205e218d29a178c';BASE='08ad7da7d9e75b4ddd1c387a22ac0affba9e1430';INV='9706e844337851329c5e30954598162ac52144c82facaf736b04475c25f0c6ec'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(n):return json.loads((OUT/n).read_bytes())
def write(n,o):(OUT/n).write_text(json.dumps(o,indent=2)+'\n')
def ref(n):p=Path(n);p=p if p.is_absolute()else OUT/p;return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def pages(n):return [x for page in load(n)for x in page]
source=load('source-commit.json');merge=load('tested-merge-commit.json');tree=load('source-tree-recursive.json')
assert source['sha']==HEAD and source['tree']['sha']==TREE and merge['sha']==MERGE and merge['tree']['sha']==TREE and tree['sha']==TREE and not tree['truncated']
assert [x['sha']for x in merge['parents']]==[BASE,HEAD]
remote={x['path']:x['sha']for x in tree['tree']if x['type']=='blob'}
reviewdir=Path('/tmp/slice3-current-review-c-02e6172-r1');comparison=json.loads((reviewdir/'FULL-INVENTORY-GIT-COMPARISON.json').read_bytes());pin=json.loads((reviewdir/'SOURCE-PIN-RECEIPT.json').read_bytes())
assert comparison['sourceHead']==HEAD and comparison['sourceTree']==TREE and comparison['sourceInventorySha256']==INV
for member in comparison['members']:assert remote[member['path']]==member['gitBlob']
for member in pin['selectedSources']:assert remote[member['path']]==member['gitBlob']
assert pin['inventoryFileCount']==1278 and pin['exactRawGitByteMatches']==1276 and pin['declaredCheckoutConversionCount']==2
inventory=Path('/tmp/slice3-source-inventory-02e6172.json');assert sha(inventory.read_bytes())==INV
(OUT/'declared-checkpoint-source-inventory.json').write_bytes(inventory.read_bytes())
identity={'kind':'IMMUTABLE_CHECKPOINT_INVENTORY_TO_EXACT_REMOTE_TESTED_TREE','sourceHead':HEAD,'sourceTree':TREE,'testedMerge':MERGE,'testedMergeTree':TREE,'testedMergeParents':[BASE,HEAD],'sourceInventorySha256':INV,'inventoryFiles':1278,'directCanonicalGitBytes':1276,'declaredCRLFConversions':2,'allInventoryMembersMatchExactRemoteTree':True,'allSelectedReviewSourcesMatchExactRemoteTree':True,'localImmutableGitReadback':ref(reviewdir/'SOURCE-PIN-RECEIPT.json'),'perFileGitComparison':ref(reviewdir/'FULL-INVENTORY-GIT-COMPARISON.json'),'remoteTree':ref('source-tree-recursive.json'),'sourceCommit':ref('source-commit.json'),'testedMergeCommit':ref('tested-merge-commit.json'),'testedMergeSignatureVerified':merge['verification']['verified'],'sourceCommitSignatureReason':source['verification']['reason'],'currentDirtyWorktreeUsed':False,'scope':'Immutable02e Git blob data and original declared1278 source inventory only. This does not claim complete backend execution or unchanged current worktree.'}
write('SOURCE-IDENTITY-COMPARISON.json',identity)
run=load('security-run-r1.json');jobs=load('security-jobs-r1.json')['jobs'];checks=load('source-check-runs-r1.json')['check_runs'];aggregate=next(x for x in checks if x['name']=='CodeQL')
assert run['id']==34008254516 and run['run_attempt']==1 and run['head_sha']==HEAD and run['status']=='completed' and run['conclusion']=='success'
assert len(jobs)==3 and {j['name']for j in jobs}=={'dependency-review','codeql-java','codeql-typescript'}
assert all(j['run_id']==run['id'] and j['run_attempt']==1 and j['head_sha']==HEAD and j['status']=='completed' and j['conclusion']=='success'for j in jobs)
assert aggregate['id']==101419434716 and aggregate['head_sha']==HEAD and aggregate['status']=='completed' and aggregate['conclusion']=='success'
assert run['pull_requests'][0]['number']==30 and run['pull_requests'][0]['base']['sha']==BASE
pr=load('pr30-r1.json');assert pr['head']['sha']==HEAD and pr['merge_commit_sha']==MERGE and pr['draft']
delta=load('ALERT-DELTA-TRIAGE.json');assert delta['added']==[] and delta['removed']==[] and delta['historicalExactExpressionMatches']==94 and delta['historicalChangedExpressions']==[]
contexts={196:'The exact historical null-dereference warning remains in the test-only privilege refusal oracle. assertThat((Throwable) refusal).isNotNull() precedes getSQLState() and aborts with AssertionError if the expected SQLException did not occur; only the allowlist above changed. The actual SQLSTATE refusal assertion and control flow remain unchanged. This quality warning stays open and is not a current authorization or safety failure.'}
for row in delta['findings']:
 if row['number']in contexts:row['engineeringAssessment']=contexts[row['number']];row['changedWholeFileContextReviewed']=True
assert all(x['number']in contexts for x in delta['findings']if x['number']in delta['wholeFileChangedWithSameExpression'])
write('ALERT-DELTA-TRIAGE.json',delta)
vs7e=load('ALERT-DELTA-VS7E.json');assert vs7e['added']==[] and vs7e['removed']==[212] and vs7e['historicalExactExpressionMatches']==94 and vs7e['historicalChangedExpressions']==[]
prior1381=json.loads(Path('/tmp/slice3-checkpoint-ci-1381ef7/ALERT-DELTA-TRIAGE.json').read_bytes());priorrows={x['number']:x for x in prior1381['findings']}
for row in vs7e['findings']:
 if row['number'] in vs7e['wholeFileChangedWithSameExpression']:
  if row['number']==196:row['engineeringAssessment']=contexts[196]
  else:
   previous=priorrows[row['number']];assert row['currentSourceSha256']==previous['currentSourceSha256'] and previous.get('changedWholeFileContextReviewed')
   row['engineeringAssessment']=previous['engineeringAssessment'];row['unchangedContextComparedDirectlyWith1381']=True
  row['changedWholeFileContextReviewed']=True
write('ALERT-DELTA-VS7E.json',vs7e)
openalerts=pages('open-alerts-pages-r1.json');dismissed=pages('dismissed-alerts-pages-r1.json');fixed=pages('fixed-alerts-pages-r1.json')
assert len(openalerts)==94 and len(dismissed)==5 and all(a['most_recent_instance']['commit_sha']==MERGE for a in openalerts+dismissed)
fixed212=next(x for x in fixed if x['number']==212);assert fixed212['state']=='fixed' and all(fixed212[k]is None for k in ['dismissed_at','dismissed_reason','dismissed_comment'])
analyses={a['category']:a for a in pages('analyses-pages-r1.json')if a['commit_sha']==MERGE};sarifs=[];sarifkeys=[]
for file,category,jobName in [('java.sarif.json','/language:java-kotlin','codeql-java'),('typescript.sarif.json','/language:javascript-typescript','codeql-typescript')]:
 analysis=analyses[category];job=next(j for j in jobs if j['name']==jobName)
 assert analysis['analysis_key']=='.github/workflows/security.yml:'+jobName and not analysis['error'] and not analysis['warning'] and job['started_at']<=analysis['created_at']<=job['completed_at']
 count=0;security=[]
 for sarif in load(file)['runs']:
  assert all(p['revisionId']==MERGE for p in sarif['versionControlProvenance'])
  rules={r['id']:r for ext in sarif['tool'].get('extensions',[])for r in ext.get('rules',[])};rules.update({r['id']:r for r in sarif['tool']['driver'].get('rules',[])})
  for result in sarif['results']:
   count+=1;loc=result['locations'][0]['physicalLocation'];region=loc['region'];path=loc['artifactLocation']['uri']
   sarifkeys.append((result['ruleId'],path,region['startLine'],region.get('endLine',region['startLine']),region.get('startColumn'),region.get('endColumn')))
   sev=rules[result['ruleId']].get('properties',{}).get('security-severity')
   if sev:security.append({'ruleId':result['ruleId'],'path':path,'region':region,'numericSecuritySeverity':sev,'scope':'Raw unchanged result; current GitHub alert/dismissal is separately reconciled.'})
 assert count==analysis['results_count']
 sarifs.append({'category':category,'analysisId':analysis['id'],'sarifId':analysis['sarif_id'],'analysisUrl':analysis['url'],'analysisKey':analysis['analysis_key'],'createdAt':analysis['created_at'],'matchingCompletedJobId':job['id'],'analysisCreatedWithinMatchingJob':True,'resultsCount':count,'rulesCount':analysis['rules_count'],'tool':analysis['tool'],'rawResponse':ref(file),'rawSecurityResults':security})
alertkeys=[]
for a in openalerts+dismissed:
 l=a['most_recent_instance']['location'];alertkeys.append((a['rule']['id'],l['path'],l['start_line'],l['end_line'],l.get('start_column'),l.get('end_column')))
assert collections.Counter(sarifkeys)==collections.Counter(alertkeys) and len(sarifkeys)==99
index=[];checkout=[];build=[];uploads=[]
with zipfile.ZipFile(OUT/'security-job-logs.zip')as z:
 assert z.testzip()is None
 for name in sorted(z.namelist()):
  raw=z.read(name);item=z.getinfo(name);index.append({'member':name,'bytes':len(raw),'sha256':sha(raw),'crc32':format(item.CRC,'08x')});lines=raw.decode('utf-8','replace').splitlines()
  if name.endswith('/2_Checkout repository.txt'):
   actual=[{'line':i+1,'text':line}for i,line in enumerate(lines)if MERGE in line or 'HEAD is now at '+MERGE[:7]+' Merge '+HEAD in line];assert actual;checkout.append({'jobName':name.split('/')[0],'member':name,'sha256':sha(raw),'lines':actual})
  if name in ['codeql-java/4_Initialise CodeQL.txt','codeql-java/5_Build the backend for analysis.txt']:
   actual=[{'line':i+1,'text':line}for i,line in enumerate(lines)if any(t in line for t in ['build-mode: manual','--begin-tracing','clean package','[INFO] Compiling ','[INFO] BUILD SUCCESS'])];build.append({'member':name,'sha256':sha(raw),'lines':actual})
  if name in ['codeql-java/6_Analyse.txt','codeql-typescript/4_Analyse.txt']:
   actual=[{'line':i+1,'text':line}for i,line in enumerate(lines)if any(t in line for t in ['Post-processing sarif files:','Uploading results','Successfully uploaded results'])];uploads.append({'member':name,'sha256':sha(raw),'lines':actual})
assert len(checkout)==3 and len(uploads)==2 and all(any('Successfully uploaded results'in l['text']for l in x['lines'])for x in uploads)
assert any('[INFO] BUILD SUCCESS'in l['text']for x in build for l in x['lines'])
write('RAW-LOG-MEMBER-INDEX.json',{'archive':ref('security-job-logs.zip'),'members':index,'zipCrcVerified':True,'checkoutProof':checkout,'actualCompiledJavaBuildProof':build,'sarifUploadProof':uploads})
annotations=pages('aggregate-codeql-annotations-pages.json');assert len(annotations)==aggregate['output']['annotations_count']==94
currenthigh=[a['number']for a in openalerts if a['rule'].get('security_severity_level')in ['high','critical']]
assert currenthigh==[]
art=load('security-artifacts-r1.json');dep=load('dependency-diff.json');assert art['total_count']==0 and art['artifacts']==[]
scan=load('SECRET-SHAPE-TRIAGE.json');assert scan['unreviewedOccurrences']==0
write('HISTORICAL-FIXED-QUALITY-NOTE-212.json',{'kind':'CURRENT_SCOPE_FIXED_NOTE_NOT_DISMISSED','sourceHead':HEAD,'testedMerge':MERGE,'alertNumber':212,'ruleId':fixed212['rule']['id'],'state':fixed212['state'],'fixedAt':fixed212['fixed_at'],'dismissedAt':None,'lastSeenLocation':fixed212['most_recent_instance']['location'],'lastSeenInstanceCommit':fixed212['most_recent_instance']['commit_sha'],'rawAuthority':ref('fixed-alerts-pages-r1.json'),'review':'The old unused AdvertisingContributionProfit profit argument was removed from recoverableProfitOf while the actual observed-cohort inputs were made explicit. This is a quality-note delta, not an added security result or an independently verified economic behavior. The last-seen location is historical and is not relabeled current.'})
write('CAPTURE-SCOPE-DISPOSITION.json',{'kind':'RAW_CAPTURE_SCOPE_AND_TRANSPORT_DISPOSITION','sourceHead':HEAD,'testedMerge':MERGE,'unselectedRawResponses':[],'allCurrentApiReadsSuccessful':all(load(x.name)['exitCode']==0 for x in OUT.glob('*.command.json')),'mutationsPerformed':False})
criteria={'allThreeSecurityJobsSuccess':True,'aggregateCodeQLSuccess':True,'exactRemoteSourceInventoryBinding':True,'actualThreeCheckoutsAndJavaBuildVerified':True,'bothExactSarifAnalysesAndAllLocationsVerified':True,'noNewSecurityHighOrCritical':True,'all94OpenExpressionsRechecked':True,'oneChangedSourceContextReviewed':True,'direct7eBaselineAlsoVerified':True,'fiveHistoricalDismissedHighKeptSeparate':True,'originalRawLogCrcVerified':True,'noUnreviewedPublicationPatternHits':True}
summary={'kind':'EXACT_SOURCE_CHECKPOINT_SECURITY_EXECUTION_RECEIPT','recordedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':HEAD,'sourceTree':TREE,'testedMerge':MERGE,'testedMergeTree':TREE,'testedMergeParents':[BASE,HEAD],'sourceInventorySha256':INV,'sourceDisposition':'UNDER_VERIFICATION','declaredCheckpointInventory':ref('declared-checkpoint-source-inventory.json'),'sourceInventoryComparison':ref('SOURCE-IDENTITY-COMPARISON.json'),'run':{k:run[k]for k in ['id','run_attempt','run_number','check_suite_id','head_sha','status','conclusion','html_url','run_started_at','updated_at']},'jobs':[{k:j[k]for k in ['id','name','run_id','run_attempt','head_sha','status','conclusion','started_at','completed_at','html_url']}for j in jobs],'aggregateCodeQL':{k:aggregate.get(k)for k in ['id','name','status','conclusion','head_sha','started_at','completed_at','details_url','output']},'aggregateAnnotations':ref('aggregate-codeql-annotations-pages.json'),'actionsArtifacts':{'totalCount':0,'artifactIds':[],'authority':ref('security-artifacts-r1.json'),'sarifOrigin':'Direct Code Scanning analysis API, exact analysis/sarif IDs; not Actions artifact IDs.'},'sarifAnalyses':sarifs,'rawSarifResultCount':99,'allRawSarifResultsMatchExactCurrentAlertLocations':True,'openAlerts':{'priorW8Count':87,'prior7eCheckpointCount':95,'prior1381CheckpointCount':94,'currentCount':94,'levelCounts':delta['levelCounts'],'added':[],'removed':[],'removedSince7e':[212],'newSecurityHighOrCritical':0,'currentOpenSecurityHighOrCritical':0,'exactFlaggedExpressionMatches':94,'wholeSourceByteMatches':93,'changedWholeSourceContextsReviewed':[196],'triage':ref('ALERT-DELTA-TRIAGE.json'),'historicalFixedQualityNote':ref('HISTORICAL-FIXED-QUALITY-NOTE-212.json')},'historicalDismissedHigh':{'count':5,'unchangedSourceAndDismissalMetadata':True,'stillPresentInRawSarif':True,'reconciliation':ref('HISTORICAL-DISMISSED-HIGH-RECONCILIATION.json')},'dependencyReview':{'actualJobResult':'success','scope':'Actual PR dependency delta only; no full repository audit/default-branch vulnerability absence claim.','addedDependencyRecords':sum(x['change_type']=='added'for x in dep),'addedVulnerabilityRecords':sum(len(x['vulnerabilities'])for x in dep if x['change_type']=='added'),'removedDependencyRecords':sum(x['change_type']=='removed'for x in dep),'rawDiff':ref('dependency-diff.json')},'rawLogs':ref('security-job-logs.zip'),'rawLogMemberIndex':ref('RAW-LOG-MEMBER-INDEX.json'),'publicationScan':ref('RAW-PUBLICATION-SCAN.json'),'secretShapeTriage':ref('SECRET-SHAPE-TRIAGE.json'),'criteria':criteria,'securityScopeResult':'SUCCESS_FOR_EXACT_02E_SECURITY_ONLY','securityLayerResult':'PASS_FOR_THIS_EXACT_SOURCE_CHECKPOINT','overallCheckpointComplete':False,'overallCheckpointAdmissibleForFinalClosure':False,'productionWriteEnabled':False,'controllerApprovalClaimMade':False,'alertsModifiedOrDismissed':False, 'limits':['Current02e full engineering verification is still separate; this successful exact-source Security layer does not establish backend/frontend/browser/supply-chain completion or Controller approval.','Current94 quality findings remain open. Five historical dismissed HIGH remain in raw SARIF. No zero-quality or zero-raw-HIGH claim.','Both baselines are independently compared:1381 has94 with no additions/removals;7e has95 with only historical note212 removed. Every remaining expression is identical.','Default main08ad still has four open HIGH fast-uri Dependabot advisories. Current PR lockfile/delta and this workflow are distinct; broader current npm/supply-chain audits require their own actual layers.','The tested merge check-run endpoint returned zero; every actual checkout and both SARIF revisions plus remote commit parents/tree establish identity.','Immutable Git and the original actual source-before inventory are used; dirty worktrees and previous failed checkpoints are not substituted.','No Ready, merge, real Provider or production enablement is supplied.']}
expected=Path('/tmp/slice3-final-execution-02e6172-r5/EXPECTED-SOURCE.json');exp=json.loads(expected.read_bytes());assert exp['sourceHead']==HEAD and exp['sourceTree']==TREE and exp['inventory']['sha256']==INV
before=Path(exp['inventory']['path']);assert sha(before.read_bytes())==INV and before.read_bytes()==inventory.read_bytes()
identityfile=Path(exp['identityEvidence']['path']);assert sha(identityfile.read_bytes())==exp['identityEvidence']['sha256'];beforeidentity=json.loads(identityfile.read_bytes());assert beforeidentity['sourceHead']==HEAD and beforeidentity['sourceTree']==TREE and beforeidentity['identityScope']=='CLEAN_COMMIT_TREE' and not beforeidentity['workingTreeDirty']
(OUT/'actual-source-before.json').write_bytes(before.read_bytes());(OUT/'actual-identity-before.json').write_bytes(identityfile.read_bytes());(OUT/'expected-source.json').write_bytes(expected.read_bytes())
extras=[]
for extra in exp['additionalExecutionInputs']:
 raw=subprocess.check_output(['git','show',HEAD+':'+extra['path']],cwd=ROOT);oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert sha(raw)==extra['sha256'] and oid==remote[extra['path']]
 extras.append({'path':extra['path'],'sha256':sha(raw),'gitBlob':oid,'scope':extra['scope'],'actualCommandNotClaimedBySecurity':True})
summary['actualSourceBefore']=ref('actual-source-before.json');summary['actualCleanIdentityBefore']=ref('actual-identity-before.json');summary['expectedSourceAtCapture']=ref('expected-source.json');summary['additionalDerivationInputGitPins']=extras
summary['openAlerts']['direct1381Baseline']=ref('ALERT-DELTA-TRIAGE.json');summary['openAlerts']['direct7eBaseline']=ref('ALERT-DELTA-VS7E.json')
depboundary=load('DEPENDABOT-DEFAULT-BRANCH-BOUNDARY.json');assert depboundary['defaultBranchHead']==BASE and depboundary['defaultBranchOpenAlertCount']==4 and all(x['severity']=='high' for x in depboundary['defaultBranchAlerts'])
assert depboundary['currentSourceLock']['fastUriEntries']==[{'path':'node_modules/fast-uri','version':'3.1.6'}] and depboundary['newVulnerabilityRecords']==0
summary['dependencyReview']['defaultBranchBoundary']=ref('DEPENDABOT-DEFAULT-BRANCH-BOUNDARY.json');summary['dependencyReview']['defaultMainOpenHigh']=4;summary['dependencyReview']['scope']='Actual PR dependency delta: no added vulnerability records. Four current default-main HIGH remain separately open. No npm audit or broader supply-chain completion claimed.'
summary['historicalCheckpointBoundaries']=[{'sourceHead':'7e66cf87afc15773d4f6e6e6717a86e7b8336ae5','securityReceipt':ref('/tmp/slice3-checkpoint-ci-7e66cf8/SECURITY-RECEIPT.json'),'scope':'Prior pre-policy-fix checkpoint only.'},{'sourceHead':'1381ef78594875a1e1304e4d9a636e49d0fab71f','securityReceipt':ref('/tmp/slice3-checkpoint-ci-1381ef7/SECURITY-RECEIPT.json'),'scope':'Failed overall backend/frontend checkpoint; Security success stays historical.'}]

assert all(criteria.values())
write('SECURITY-RECEIPT.json',summary)
write('DERIVATION-RECEIPT.json',{'kind':'SECURITY_RAW_EVIDENCE_DERIVATION_ONLY','sourceHead':HEAD,'testedMerge':MERGE,'scripts':[ref(x)for x in ['capture.py','reconcile_current_alerts.py','reconcile_vs7e.py','finish_security_evidence.py','build_dependency_boundary.py','build_security_receipt.py']],'sourcePinInput':ref(reviewdir/'SOURCE-PIN-RECEIPT.json'),'result':ref('SECURITY-RECEIPT.json'),'apiCommands':[ref(p)for p in sorted(OUT.glob('*.command.json'))],'productExecutionPerformed':False,'repositoryMutationsPerformed':False})
print(json.dumps({'scope':summary['securityScopeResult'],'overallCheckpointComplete':False,'rawSarif':99,'openQuality':94,'historicalDismissedHigh':5,'rawLogMembers':len(index),'receipt':ref('SECURITY-RECEIPT.json')}))

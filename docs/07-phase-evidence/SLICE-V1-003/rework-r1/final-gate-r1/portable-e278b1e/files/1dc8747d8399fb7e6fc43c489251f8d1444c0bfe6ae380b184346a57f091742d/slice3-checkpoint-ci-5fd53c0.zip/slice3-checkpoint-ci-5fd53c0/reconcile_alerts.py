#!/usr/bin/env python3
from pathlib import Path
import collections,hashlib,json,subprocess
ROOT=Path('/Users/chzhengx/Code/personal/marketops-platform')
OUT=Path(__file__).resolve().parent
OLD=ROOT/'docs/07-phase-evidence/SLICE-V1-003/rework-r1/workstreams/security-w8/w7-w8-alert-delta.json'
old=json.loads(OLD.read_text());prior={row['number']:row for row in old['alerts']}
current=[row for page in json.loads((OUT/'open-alerts-pages.json').read_text()) for row in page]
cache={}
def contents(head,path):
 key=(head,path)
 if key not in cache:
  cache[key]=subprocess.check_output(['git','show',head+':'+path],cwd=ROOT)
 return cache[key]
def expression(raw,location):
 lines=raw.decode().splitlines(keepends=True)[location['start_line']-1:location['end_line']]
 if len(lines)==1:return lines[0][location['start_column']-1:location['end_column']-1]
 lines[0]=lines[0][location['start_column']-1:];lines[-1]=lines[-1][:location['end_column']-1]
 return ''.join(lines)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
triage={
 217:('ACCURATE_NON_SECURITY_MAINTAINABILITY_NOTE','The computed purpose local is never read. It is a pure string ternary with no side effect. The next freshnessRules.resolve call consumes the frozen stage directly and chooses per-kind purpose authority; no intended validation or scope value is dropped by this unused local. Root-cause behavior is checked by the purpose/profile and vertical path tests. This note remains open; no dismissal or clean-CodeQL claim.'),
 218:('ACCURATE_TEST_ONLY_MAINTAINABILITY_NOTE','The saved half-window local is unused in the test fixture. The actual to/read fields are explicitly assigned and consumed by the settlement inputs and assertions. No production computation or safety control uses the unused local. This note remains open.'),
 219:('TEST_FIXTURE_FAILURE_IS_INTENTIONAL','This package-private fixture method converts only test-authored availability quantity strings. The nonnumeric SELLABILITY branch never reaches conversion. A malformed fixture quantity should throw and fail JUnit instead of being converted into admissible evidence; there is no external/request input to this method. This is not a production error-handling omission.'),
 220:('TEST_ONLY_DEPRECATED_COMPATIBILITY_CALL','The Jackson JsonNode.asText call reads a test assertion value and the returned value is checked against the exact recovery-state string. Deprecation is a maintenance note; this call does not skip the assertion or confer authority. The dependency is pinned. The note remains open and no removal/change is claimed.'),
}
rows=[]
for alert in sorted(current,key=lambda r:r['number']):
 location=alert['most_recent_instance']['location'];path=location['path'];raw=contents('5fd53c0959ad50d949ee92c7477f1fef9954f2a2',path)
 ex=expression(raw,location)
 row={'number':alert['number'],'ruleId':alert['rule']['id'],'level':alert['rule']['severity'],
  'securitySeverity':alert['rule'].get('security_severity_level'),'state':alert['state'],
  'currentLocation':location,'currentSourceSha256':sha(raw),'currentFlaggedExpressionSha256':sha(ex.encode()),
  'currentCommit':alert['most_recent_instance']['commit_sha']}
 if alert['number'] in prior:
  former=prior[alert['number']];older=contents(old['head'],former['currentLocation']['path']);oldex=expression(older,former['currentLocation'])
  row.update(disposition='HISTORICAL_OPEN_QUALITY_NOTE_OR_WARNING_RECHECKED',previousLocation=former['currentLocation'],
   priorSourceSha256=sha(older),priorFlaggedExpressionSha256=sha(oldex.encode()),sameExactFlaggedExpression=oldex==ex,
   sameWholeFile=raw==older,locationMoved=location!=former['currentLocation'],priorTriage=former['priorTriage'],
   engineeringAssessment='Exact flagged expression matches the historical bounded triage; current whole-file/source identity and location are recorded separately.' if oldex==ex else 'CHANGED_EXPRESSION_REQUIRES_SPECIFIC_REVIEW')
 else:
  kind,reason=triage[alert['number']];row.update(disposition=kind,engineeringAssessment=reason)
 rows.append(row)
removed=sorted(set(prior)-{x['number'] for x in current})
report={'kind':'EXACT_CHECKPOINT_OPEN_ALERT_DELTA_AND_BOUNDED_TRIAGE','sourceHead':'5fd53c0959ad50d949ee92c7477f1fef9954f2a2',
 'testedMerge':'5b7a56867d04d4cb8228e98aeefb8b3065c99430','priorSourceHead':old['head'],
 'priorEvidence':{'path':str(OLD.relative_to(ROOT)),'sha256':sha(OLD.read_bytes())},
 'priorOpenCount':len(prior),'currentOpenCount':len(current),'added':[x['number'] for x in current if x['number'] not in prior],
 'removed':removed,'levelCounts':dict(collections.Counter(x['level'] for x in rows)),
 'newSecuritySeverityFindings':sum(x['securitySeverity'] is not None for x in rows if x['number'] not in prior),
 'historicalExactExpressionMatches':sum(x.get('sameExactFlaggedExpression') is True for x in rows),
 'historicalWholeFileMatches':sum(x.get('sameWholeFile') is True for x in rows),
 'historicalChangedExpressions':[x['number'] for x in rows if x.get('sameExactFlaggedExpression') is False],
 'findings':rows,'controllerApprovalClaimMade':False,'alertDismissalsPerformed':False,
 'boundary':'Open quality notes/warnings are preserved; this does not claim zero raw SARIF security results, no quality findings, independent approval, or final evidence-commit CI.'}
(OUT/'ALERT-DELTA-TRIAGE.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['priorOpenCount','currentOpenCount','added','removed','levelCounts','historicalExactExpressionMatches','historicalWholeFileMatches','historicalChangedExpressions']}))

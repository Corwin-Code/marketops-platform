# Exact checkpoint Security evidence

This directory is read-only evidence for source Head `5fd53c0959ad50d949ee92c7477f1fef9954f2a2`, tested merge `5b7a56867d04d4cb8228e98aeefb8b3065c99430`, shared exact tree `7bbd93849f7c5208f5a7922df69414f7a923a007`, PR #30. It does not identify the later final evidence commit.

`SECURITY-RECEIPT.json` binds the actual Security run 33994962301, attempt 1, its three successful jobs, successful aggregate CodeQL check, direct raw SARIF analyses, raw log ZIP members, dependency delta, source identity comparison and alert reconciliation. Security uploads no Actions artifacts; the recorded analysis IDs identify the direct Code Scanning SARIF API payloads instead.

The executed inventory is preserved verbatim. All 1265 inputs match the exact remote tree under committed checkout rules: 1263 directly and 2 with explicitly recorded reversible CRLF checkout conversion. Every job's raw checkout log and both SARIF provenances bind the tested merge. Check runs are attached to source Head; the tested-merge check-run endpoint returned an empty listing.

There are 91 open quality findings, compared with 87 at W8. Every historical flagged expression is unchanged. The four new non-security notes remain open with narrow engineering triage. Five historically dismissed HIGH findings remain present in the original SARIF; their source bytes and dismissal metadata are unchanged. All 96 SARIF rule/location tuples match the 91 open and 5 dismissed alert instances exactly. No alert was dismissed or changed by this collector.

Every GitHub request retains a raw response, stderr and command/exit/hash record. Empty or partial EOF transport responses are preserved under their original filenames; later successful retries have new filenames. The early neutral aggregate snapshot is preserved. Only successful current raw responses are used by the receipt.

`RAW-PUBLICATION-SCAN.json` retains the scan result before triage. The only matches are exact SHA-256-matched historical static CodeQL rule-help examples in the TypeScript SARIF. `SECRET-SHAPE-TRIAGE.json` records their actual rule IDs and JSON pointers without displaying matched values. The original SARIF and log bytes remain unchanged.

Raw collector: `capture.py`. Derived reconciliation: `reconcile_alerts.py`, `finish_security_evidence.py`, `build_receipt.py`. The latter records retrieval-time evidence; regenerating it creates a new receipt timestamp and must be treated as a new derived receipt, not a replacement of this archive.

Production writes remain disabled. This receipt does not claim independent Controller approval, zero quality findings, zero raw HIGH results, complete backend regression, or CI for a later evidence commit.

#!/usr/bin/env python3
from pathlib import Path
import collections,hashlib,json,subprocess,zipfile
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/chzhengx/Code/personal/marketops-platform')
HEAD='5fd53c0959ad50d949ee92c7477f1fef9954f2a2';MERGE='5b7a56867d04d4cb8228e98aeefb8b3065c99430'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda name:json.loads((OUT/name).read_text())
def write(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def ref(name):
 p=OUT/name;return {'path':name,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
run=load('security-run-final.json');jobs=load('security-jobs-r2.json')['jobs'];checks=load('source-check-runs-r3.json')['check_runs'];aggregate=next(c for c in checks if c['name']=='CodeQL')
identity=load('SOURCE-IDENTITY-COMPARISON.json');openalerts=[a for page in load('open-alerts-pages.json') for a in page];dismissed=[a for page in load('dismissed-alerts-pages.json') for a in page]
assert run['head_sha']==HEAD and run['conclusion']=='success' and run['status']=='completed' and run['run_attempt']==1
assert len(jobs)==3 and all(j['conclusion']=='success' and j['status']=='completed' for j in jobs)
assert aggregate['head_sha']==HEAD and aggregate['conclusion']=='success' and aggregate['status']=='completed'
assert all(a['most_recent_instance']['commit_sha']==MERGE for a in openalerts+dismissed)
analyses={a['category']:a for page in load('analyses-pages-r2.json') for a in page if a['commit_sha']==MERGE}
sarifs=[];sarifkeys=[]
for name,category in [('java.sarif-r2.json','/language:java-kotlin'),('typescript.sarif.json','/language:javascript-typescript')]:
 doc=load(name);analysis=analyses[category];count=0;security=[]
 for sarifrun in doc['runs']:
  assert all(p['revisionId']==MERGE for p in sarifrun['versionControlProvenance'])
  rules={r['id']:r for ext in sarifrun['tool'].get('extensions',[]) for r in ext.get('rules',[])}
  rules.update({r['id']:r for r in sarifrun['tool']['driver'].get('rules',[])})
  for result in sarifrun['results']:
   count+=1;loc=result['locations'][0]['physicalLocation'];region=loc['region'];path=loc['artifactLocation']['uri']
   key=(result['ruleId'],path,region['startLine'],region.get('endLine',region['startLine']),region.get('startColumn'),region.get('endColumn'));sarifkeys.append(key)
   severity=rules[result['ruleId']].get('properties',{}).get('security-severity')
   if severity:security.append({'ruleId':result['ruleId'],'path':path,'region':region,'numericSecuritySeverity':severity,'dispositionOrigin':'GitHub alert API history, not SARIF suppression'})
 assert count==analysis['results_count'] and not analysis['error'] and not analysis['warning']
 sarifs.append({'category':category,'analysisId':analysis['id'],'analysisUrl':analysis['url'],'resultsCount':count,'rulesCount':analysis['rules_count'],'tool':analysis['tool'],'rawResponse':ref(name),'rawSecurityResults':security})
alertkeys=[]
for a in openalerts+dismissed:
 loc=a['most_recent_instance']['location'];alertkeys.append((a['rule']['id'],loc['path'],loc['start_line'],loc['end_line'],loc.get('start_column'),loc.get('end_column')))
assert collections.Counter(sarifkeys)==collections.Counter(alertkeys),(collections.Counter(sarifkeys)-collections.Counter(alertkeys),collections.Counter(alertkeys)-collections.Counter(sarifkeys))
zipindex=[];checkout=[]
with zipfile.ZipFile(OUT/'security-job-logs.zip') as archive:
 assert archive.testzip() is None
 for member in sorted(archive.namelist()):
  raw=archive.read(member);zipindex.append({'member':member,'bytes':len(raw),'sha256':sha(raw)})
  if member.endswith('/2_Checkout repository.txt'):
   lines=raw.decode().splitlines();proof=[{'line':i+1,'text':line} for i,line in enumerate(lines) if MERGE in line or 'HEAD is now at 5b7a568 Merge '+HEAD in line]
   assert proof;checkout.append({'jobName':member.split('/')[0],'zipMember':member,'memberSha256':sha(raw),'lines':proof})
write('RAW-LOG-MEMBER-INDEX.json',{'archive':ref('security-job-logs.zip'),'members':zipindex,'checkoutProof':checkout,'zipCrcVerified':True})
# Preserve exact reviewed expression for the four new non-security notes.
delta=load('ALERT-DELTA-TRIAGE.json')
for row in delta['findings']:
 if row['number'] in [217,218,219,220]:
  loc=row['currentLocation'];raw=subprocess.check_output(['git','show',HEAD+':'+loc['path']],cwd=ROOT);lines=raw.decode().splitlines(keepends=True)[loc['start_line']-1:loc['end_line']]
  if len(lines)==1:ex=lines[0][loc['start_column']-1:loc['end_column']-1]
  else:
   lines[0]=lines[0][loc['start_column']-1:];lines[-1]=lines[-1][:loc['end_column']-1];ex=''.join(lines)
  assert sha(ex.encode())==row['currentFlaggedExpressionSha256'];row['exactNewFlaggedExpression']=ex
write('ALERT-DELTA-TRIAGE.json',delta)
dependency=load('dependency-diff.json');added=[d for d in dependency if d['change_type']=='added'];removed=[d for d in dependency if d['change_type']=='removed']
assert not any(d['vulnerabilities'] for d in added)
summary={'kind':'EXACT_SOURCE_CHECKPOINT_SECURITY_EXECUTION_RECEIPT','recordedAtUTC':datetime.now(timezone.utc).isoformat(),
 'sourceHead':HEAD,'sourceTree':identity['sourceTree'],'testedMerge':MERGE,'testedMergeTree':identity['testedMergeTree'],'testedMergeParents':identity['testedMergeParents'],
 'executionSourceInventory':ref('executed-source-inventory.json'),'sourceInventoryComparison':ref('SOURCE-IDENTITY-COMPARISON.json'),
 'sourceIdentity':{'inputFiles':identity['inventoryFiles'],'directByteMatches':identity['directByteMatches'],'declaredCrLfCheckoutConversions':identity['declaredCrLfCheckoutConversions'],'allMeasuredInputsMatchExactRemoteTreeUnderDeclaredCheckoutRules':True,'signedMergeParentsAndTreeVerified':True},
 'run':{k:run[k] for k in ['id','run_attempt','check_suite_id','head_sha','status','conclusion','html_url','run_started_at','updated_at']},
 'jobs':[{k:j[k] for k in ['id','name','run_id','run_attempt','head_sha','status','conclusion','started_at','completed_at','html_url']} for j in jobs],
 'aggregateCodeQL':{k:aggregate.get(k) for k in ['id','name','status','conclusion','head_sha','started_at','completed_at','details_url']},
 'actionsArtifacts':{'totalCount':load('security-artifacts.json')['total_count'],'artifactIds':[],'authority':ref('security-artifacts.json'),'sarifOrigin':'Direct Code Scanning analysis API response with exact analysis ID; not an Actions uploaded artifact.'},
 'sarifAnalyses':sarifs,'rawSarifResultCount':len(sarifkeys),'allRawSarifResultsMatchExactCurrentAlertLocations':True,
 'openAlerts':{'priorW8Count':delta['priorOpenCount'],'currentCount':delta['currentOpenCount'],'levelCounts':delta['levelCounts'],'new':[217,218,219,220],'newSecurityHighOrCritical':sum(a['rule'].get('security_severity_level') in ['high','critical'] for a in openalerts if a['number'] in delta['added']),'currentOpenSecurityHighOrCritical':sum(a['rule'].get('security_severity_level') in ['high','critical'] for a in openalerts),'historicalExpressionMatches':delta['historicalExactExpressionMatches'],'triage':ref('ALERT-DELTA-TRIAGE.json')},
 'historicalDismissedHigh':{'count':len(dismissed),'sourceAndDismissalMetadataUnchanged':True,'reconciliation':ref('HISTORICAL-DISMISSED-HIGH-RECONCILIATION.json'),'stillPresentInRawSarif':True},
 'dependencyReview':{'failOnSeverity':'moderate','addedDependencyRecords':len(added),'addedVulnerabilityRecords':sum(len(d['vulnerabilities']) for d in added),'removedDependencyRecords':len(removed),'removedVulnerabilityRecords':sum(len(d['vulnerabilities']) for d in removed),'rawDiff':ref('dependency-diff.json'),'logMember':'dependency-review/3_Review the dependencies this change introduces.txt','boundary':'PR dependency delta plus actual action result. Separate full supply-chain inventories/audits remain a different layer.'},
 'rawLogs':ref('security-job-logs.zip'),'rawLogMemberIndex':ref('RAW-LOG-MEMBER-INDEX.json'),
 'publicationScan':ref('RAW-PUBLICATION-SCAN.json'),'secretShapeTriage':ref('SECRET-SHAPE-TRIAGE.json'),
 'criteria':{'allThreeSecurityJobsSuccess':True,'aggregateCodeQLSuccess':True,'exactSourceBindingVerified':True,'noNewSecurityHighOrCritical':True,'allHistoricalOpenExpressionsRechecked':True,'historicalDismissedHighSeparated':True,'rawPayloadSafeAfterExactStaticRuleHelpTriage':load('SECRET-SHAPE-TRIAGE.json')['safeToPublishOriginalPayloads']},
 'securityLayerResult':'PASS_FOR_THIS_EXACT_SOURCE_CHECKPOINT','productionWriteEnabled':False,'controllerApprovalClaimMade':False,'newDismissalsPerformed':False,
 'limits':['This is checkpoint 5fd53c0 CI, not the future final evidence commit CI.','The source-Head API attaches check runs; tested-merge check-run listing returned zero. Actual merge checkout is proved by every job checkout log and both SARIF provenances.','Open quality findings increased from 87 to 91. Four new notes are bounded and remain open.','Five historical dismissed HIGH findings remain in raw SARIF, with source and dismissal history unchanged.','The original early neutral aggregate snapshot and transient EOF API attempts remain preserved. Only later successful raw responses support this receipt.','No conclusion is made about still-running backend/full regression or independent Controller acceptance.']}
assert all(summary['criteria'].values())
write('SECURITY-RECEIPT.json',summary)
print(json.dumps({'result':summary['securityLayerResult'],'rawSarifCount':len(sarifkeys),'exactAlertLocationMatches':len(alertkeys),'rawLogMembers':len(zipindex),'receipt':ref('SECURITY-RECEIPT.json')}))
